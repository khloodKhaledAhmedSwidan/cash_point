<?php $__env->startSection('title'); ?>
    Be right back
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>




    <div class="row">
        <div class="col-md-12">
            <!-- BEGIN EXAMPLE TABLE PORTLET-->
            <div class="portlet light bordered" >

                <div class="portlet-body" style="text-align: center;">
                    <div class="title">لا تسطيع الدخول لانك لا تملك الصلاحية</div>
                    <br>
                    <div class="text-right" style="text-align: center;">
                        <a class="btn sbold green" href="<?php echo e(url('/admin/home')); ?>">عودة للرئيسية
                            <i class="fa fa-arrow-left"></i>
                        </a>
                    </div>
                </div>
            </div>
            <!-- END EXAMPLE TABLE PORTLET-->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\orderMosb2a\resources\views/errors/not_access.blade.php ENDPATH**/ ?>