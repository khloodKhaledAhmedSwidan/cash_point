<?php $__env->startSection('title'); ?>
    الصور
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/bootstrap-fileinput.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="/admin/home">لوحة التحكم</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="/admin/setting/images">الصور</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>تعديل الصور</span>
            </li>
        </ul>
    </div>

    <h1 class="page-title"> الصور
        <small>تعديل الصور</small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <!-- BEGIN PORTLET-->
            <div class="portlet light form-fit bordered">

                <div class="portlet-body form">
                    <!-- BEGIN FORM-->
                    <form action="/admin/add/imagesSetting" class="form-horizontal form-bordered" enctype="multipart/form-data" method="post">
                        <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                        <div class="form-body">
                            <div class="form-group ">

                                <label class="control-label col-md-3">أيقونة</label>
                                <div class="col-md-9">
                                    <div class="fileinput fileinput-new" data-provides="fileinput">
                                        <div class="fileinput-preview thumbnail" data-trigger="fileinput" style="width: 200px; height: 150px;">
                                            <?php if($settings->fav_icon !==null): ?>
                                                <img   src='<?php echo e(asset("img/$settings->fav_icon")); ?>'>
                                            <?php endif; ?>
                                        </div>
                                        <div>
                                                                <span class="btn red btn-outline btn-file">
                                                                    <span class="fileinput-new"> اختر الصورة </span>
                                                                    <span class="fileinput-exists"> تغيير </span>
                                                                    <input type="file" name="fav_icon"> </span>
                                            <a href="javascript:;" class="btn red fileinput-exists" data-dismiss="fileinput"> إزالة </a>
                                            <a id="delete-fav" class="btn btn-default">
                                                حذف <span class="fa fa-trash-o"></span></a>
                                        </div>
                                    </div>
                                </div>
                                <?php if($errors->has('fav_icon')): ?>
                                    <span class="help-block">
                                           <strong style="color: red;"><?php echo e($errors->first('fav_icon')); ?></strong>
                                        </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-body">
                            <div class="form-group ">
                                <label class="control-label col-md-3">لوجو أعلى الصفحة</label>
                                <div class="col-md-9">
                                    <div class="fileinput fileinput-new" data-provides="fileinput">
                                        <div class="fileinput-preview thumbnail" data-trigger="fileinput" style="width: 200px; height: 150px;">
                                            <?php if($settings->logo_header !==null): ?>
                                                <img   src='<?php echo e(asset("img/$settings->logo_header")); ?>'>
                                            <?php endif; ?></div>
                                        <div>
                                                                <span class="btn red btn-outline btn-file">
                                                                    <span class="fileinput-new"> اختر الصورة </span>
                                                                    <span class="fileinput-exists"> تغيير </span>
                                                                    <input type="file" name="logo_header"> </span>
                                            <a href="javascript:;" class="btn red fileinput-exists" data-dismiss="fileinput"> إزالة </a>
                                            <a id="delete-logo-h" class="btn btn-default">
                                                حذف <span class="fa fa-trash-o"></span></a>


                                        </div>
                                    </div>

                                </div>
                                <?php if($errors->has('logo_header')): ?>
                                    <span class="help-block">
                                           <strong style="color: red;"><?php echo e($errors->first('logo_header')); ?></strong>
                                        </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-body">
                            <div class="form-group ">

                                <label class="control-label col-md-3">لوجو أسفل الصفحة</label>
                                <div class="col-md-9">
                                    <div class="fileinput fileinput-new" data-provides="fileinput">
                                        <div class="fileinput-preview thumbnail" data-trigger="fileinput" style="width: 200px; height: 150px;">
                                            <?php if($settings->logo_footer !==null): ?>
                                                <img   src='<?php echo e(asset("img/$settings->logo_footer")); ?>'>
                                            <?php endif; ?></div>
                                        <div>
                                                                <span class="btn red btn-outline btn-file">
                                                                    <span class="fileinput-new"> اختر الصورة  </span>
                                                                    <span class="fileinput-exists"> تغيير </span>
                                                                    <input type="file" name="logo_footer"> </span>
                                            <a href="javascript:;" class="btn red fileinput-exists" data-dismiss="fileinput"> إزالة </a>
                                            <a id="delete-logo-f" class="btn btn-default">
                                                حذف <span class="fa fa-trash-o"></span></a>

                                        </div>
                                    </div>

                                </div>
                                <?php if($errors->has('logo_footer')): ?>
                                    <span class="help-block">
                                           <strong style="color: red;"><?php echo e($errors->first('logo_footer')); ?></strong>
                                        </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-actions">
                            <div class="row">
                                <div class="col-md-offset-3 col-md-9">
                                    <button type="submit" class="btn green">حفظ</button>
                                </div>
                            </div>
                        </div>
                    </form>
                    <!-- END FORM-->
                </div>
            </div>
            <!-- END PORTLET-->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('admin/js/bootstrap-fileinput.js')); ?>"></script>
    <script>
        $(document).ready(function() {

//ajax laravel
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="X-CSRF-TOKEN"]').attr('content')
                }
            });
        });
    </script>
    <script src="<?php echo e(URL::asset('admin/js/delete-images.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\orderMosb2a\resources\views/admin/settings/images.blade.php ENDPATH**/ ?>