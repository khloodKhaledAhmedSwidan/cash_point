<?php $__env->startSection('title'); ?>
    الدول
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/datatables.bootstrap-rtl.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/sweetalert.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/sweetalert.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="/admin/home">لوحة التحكم</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="<?php echo e(url('/admin/countries')); ?>">الدول</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>عرض الدول </span>
            </li>
        </ul>
    </div>

    <h1 class="page-title">عرض الدول
        <small>عرض جميع الدول</small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-lg-12">
            <!-- BEGIN EXAMPLE TABLE PORTLET-->
            <div class="portlet light bordered table-responsive">
                <div class="portlet-body">
                    <div class="table-toolbar">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="btn-group">
                                <a class="btn sbold green" href="<?php echo e(route('countries.create')); ?>"> إضافة جديد
                                <i class="fa fa-plus"></i>
                                </a>
                                </div>
                            </div>

                        </div>
                    </div>
                    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                        <thead>
                        <tr>
                            <th>
                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                    <input type="checkbox" class="group-checkable" data-set="#sample_1 .checkboxes" />
                                    <span></span>
                                </label>
                            </th>
                            <th></th>
                            <th> الاسم</th>
                            <th> الكود</th>
                            <th> العملة</th>
                            <th> الصورة</th>
                            <th>  عدد الاختيارات  </th>
                        
                            <th> العمليات </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $i=0 ?>
                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="odd gradeX">
                                <td>
                                    <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                        <input type="checkbox" class="checkboxes" value="1" />
                                        <span></span>
                                    </label>
                                </td>
                                <td><?php echo ++$i ?></td>
                                <td> <?php echo e($country->name); ?> </td>
                                <td> <?php echo e($country->code); ?> </td>
                                <td> <?php echo e($country->currency); ?> </td>
                                <td> <img src="<?php echo e(asset('uploads/countries/'.$country->image)); ?>" style=" border-squere: 50%; width:15%; "> </td>
                                <td><?php echo e($country->users()->count()); ?> </td>

                      




                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-xs green dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"> العمليات
                                            <i class="fa fa-angle-down"></i>
                                        </button>
                                        <ul class="dropdown-menu pull-left" role="menu">
                                 
                                            <li>
                                                <a href="<?php echo e(route('countries.edit',$country->id)); ?>">
                                                    <i class="icon-docs"></i> تعديل </a>
                                            </li>
                                            <li>
                                                <a class="delete_user" data="<?php echo e($country->id); ?>" data_name="<?php echo e($country->name); ?>" >
                                                    <i class="fa fa-key"></i> مسح
                                                </a>
                                            </li>

                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- END EXAMPLE TABLE PORTLET-->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('admin/js/datatable.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/datatables.bootstrap.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/table-datatables-managed.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/sweetalert.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/ui-sweetalert.min.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            var CSRF_TOKEN = $('meta[name="X-CSRF-TOKEN"]').attr('content');

            $('body').on('click', '.delete_user', function() {
                var id = $(this).attr('data');

                var swal_text = 'حذف ' + $(this).attr('data_name') + '؟';
                var swal_title = 'هل أنت متأكد من الحذف ؟';

                swal({
                    title: swal_title,
                    text: swal_text,
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonClass: "btn-warning",
                    confirmButtonText: "تأكيد",
                    cancelButtonText: "إغلاق",
                    closeOnConfirm: false
                }, function() {

                    window.location.href = "<?php echo e(url('/')); ?>" + "/admin/delete/"+id+"/country";


                });

            });

        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\TQNEE\cash-point\resources\views/admin/countries/index.blade.php ENDPATH**/ ?>