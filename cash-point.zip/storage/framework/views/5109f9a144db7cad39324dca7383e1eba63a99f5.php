<?php $__env->startSection('title'); ?>
    من نحن
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/bootstrap-fileinput.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="/admin/home">لوحة التحكم</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="/admin/pages/about">من نحن</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>تعديل من نحن</span>
            </li>
        </ul>
    </div>

    <h1 class="page-title"> من نحن
        <small>تعديل من نحن</small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="row">

        <div class="col-md-8">
            <!-- BEGIN TAB PORTLET-->
            <?php if(count($errors)): ?>
                <ul class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
            <form action="<?php echo e(url('admin/add/pages/about')); ?>" method="post">
                <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>

                                    <!-- BEGIN CONTENT -->
        <div class="page-content-wrapper">
                                        <!-- BEGIN CONTENT BODY -->

            <div class="row">
                <!-- BEGIN SAMPLE FORM PORTLET-->
                <div class="portlet light bordered table-responsive">
                    <div class="portlet-body form">
                        <div class="form-horizontal" role="form">
                            <div class="form-body">
                                <div class="form-group">
                                    <label class="col-md-3 control-label">العنوان</label>
                                    <div class="col-md-9">


                                            <input type="text" class="form-control" placeholder="العنوان" name="title" value="<?php echo e($settings->title); ?>">


                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">المحتوي</label>
                                    <div class="col-md-9">


                                        <textarea type="text" id="description2" class="form-control" placeholder="المحتوي" name="content" ><?php echo e($settings->content); ?></textarea>


                                    </div>
                                </div>






                            </div>

                        </div>
                    </div>
                </div>
                <!-- END SAMPLE FORM PORTLET-->


        </div>


            <!-- END CONTENT BODY -->
    </div>
                                    <!-- END CONTENT -->







                <div class="form-actions">
                    <div class="row">
                        <div class="col-md-offset-3 col-md-9">
                            <button type="submit" class="btn green">حفظ</button>
                        </div>
                    </div>
                </div>
            </form>
            <!-- END TAB PORTLET-->





        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script src="<?php echo e(URL::asset('admin/ckeditor/ckeditor.js')); ?>"></script>
    <script>

        CKEDITOR.replace('description2');
    </script>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sawaq\resources\views/admin/pages/about.blade.php ENDPATH**/ ?>