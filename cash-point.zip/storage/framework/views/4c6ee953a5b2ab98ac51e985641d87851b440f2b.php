<?php $__env->startSection('title'); ?>
    تعديل بيانات الصفحة
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/select2-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/bootstrap-fileinput.css')); ?>">


<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="/admin/home">لوحة التحكم</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="/admin/setting/pages">الصفحات</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>عرض الصفحات</span>
            </li>
        </ul>
    </div>

    <h1 class="page-title">عرض الصفحات
        <small>تعديل بيانات الصفحة</small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-md-8">
            <!-- BEGIN TAB PORTLET-->
            <form method="post" action="/admin/update/page/<?php echo e($page->id); ?>" >
                <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                <div class="portlet light bordered">

                    <div class="portlet-body">

                        <div class="tabbable tabbable-tabdrop">
                            <ul class="nav nav-tabs">
                                <li class="active">
                                    <a href="#tab1" data-toggle="tab">عربي</a>
                                </li>
                                <li>
                                    <a href="#tab2" data-toggle="tab">انجيلزي</a>
                                </li>

                            </ul>

                            <div class="tab-content">
                                <div class="tab-pane active" id="tab1">
                                    <!-- BEGIN CONTENT -->
                                    <div class="page-content-wrapper">
                                        <!-- BEGIN CONTENT BODY -->

                                        <div class="row">
                                            <!-- BEGIN SAMPLE FORM PORTLET-->
                                            <div class="portlet light bordered">
                                                <div class="portlet-body form">
                                                    <div class="form-horizontal" role="form">
                                                        <div class="form-body">
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">الاسم</label>
                                                                <div class="col-md-9">
                                                                    <input type="text" name="page_name[ar]" class="form-control" placeholder="الاسم" value="<?php echo e(unserialize($page->title)['ar']); ?>">
                                                                    <?php if($errors->has('page_name.ar')): ?>
                                                                        <span class="help-block">
                                                                                               <strong style="color: red;"><?php echo e($errors->first('page_name.ar')); ?></strong>
                                                                                            </span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="facebook" class="col-lg-3 control-label">المحتوى</label>
                                                            <div class="col-lg-9">
                                                                
                                                                <textarea id="description2" name="text[ar]" class="form-control"><?php echo unserialize($page->text)['ar']; ?></textarea>
                                                                <?php if($errors->has('text.ar')): ?>
                                                                    <span class="help-block">
                                                                           <strong style="color: red;"><?php echo e($errors->first('text.ar')); ?></strong>
                                                                        </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>



                                                    </div>
                                                </div>
                                            </div>
                                            <!-- END SAMPLE FORM PORTLET-->


                                        </div>


                                        <!-- END CONTENT BODY -->
                                    </div>
                                    <!-- END CONTENT -->

                                </div>
                                <div class="tab-pane" id="tab2">
                                    <!-- BEGIN CONTENT -->
                                    <div class="page-content-wrapper">
                                        <!-- BEGIN CONTENT BODY -->

                                        <div class="row">
                                            <!-- BEGIN SAMPLE FORM PORTLET-->
                                            <div class="portlet light bordered">
                                                <div class="portlet-body form">
                                                    <div class="form-horizontal" role="form">
                                                        <div class="form-body">
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">الاسم</label>
                                                                <div class="col-md-9">
                                                                    <input type="text" name="page_name[en]" class="form-control" placeholder="الاسم" value="<?php echo e(unserialize($page->title)['en']); ?>">
                                                                    <?php if($errors->has('page_name.en')): ?>
                                                                        <span class="help-block">
                                                                                               <strong style="color: red;"><?php echo e($errors->first('page_name.en')); ?></strong>
                                                                                            </span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>



                                                        <div class="form-group">
                                                            <label for="facebook" class="col-lg-3 control-label">المحتوى</label>
                                                            <div class="col-lg-9">
                                                                
                                                                <textarea id="description1" name="text[en]" class="form-control"><?php echo unserialize($page->text)['en']; ?></textarea>
                                                                <?php if($errors->has('text.en')): ?>
                                                                    <span class="help-block">
                                                                           <strong style="color: red;"><?php echo e($errors->first('text.en')); ?></strong>
                                                                        </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>


                                                    </div>
                                                </div>
                                            </div>
                                            <!-- END SAMPLE FORM PORTLET-->


                                        </div>


                                        <!-- END CONTENT BODY -->
                                    </div>
                                    <!-- END CONTENT -->
                                </div>

                            </div>


                        </div>


                        <p> &nbsp; </p>
                        <p> &nbsp; </p>

                    </div>
                </div>
                <div class="form-actions">
                    <div class="row">
                        <div class="col-md-offset-3 col-md-9">
                            <button type="submit" class="btn green">حفظ</button>
                        </div>
                    </div>
                </div>
            </form>
            <!-- END TAB PORTLET-->





        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('admin/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/components-select2.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/bootstrap-fileinput.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/ckeditor/ckeditor.js')); ?>"></script>
    <script>
        CKEDITOR.replace('description1');
        CKEDITOR.replace('description2');
    </script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\orderMosb2a\resources\views/admin/pages/edit.blade.php ENDPATH**/ ?>