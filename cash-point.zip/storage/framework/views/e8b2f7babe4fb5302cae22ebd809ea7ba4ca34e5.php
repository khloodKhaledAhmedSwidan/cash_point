<?php $__env->startSection('title'); ?>
    مجموعات المشرفين
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('assetes/admin/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('assetes/admin/css/select2-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('assetes/admin/css/bootstrap-fileinput.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('assetes/admin/css/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('assetes/admin/css/datatables.bootstrap-rtl.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('assetes/admin/css/sweetalert.css')); ?>">
    <link href="<?php echo e(URL::asset('assetes/admin/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assetes/admin/css/simple-line-icons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assetes/admin/css/bootstrap-rtl.min.css"')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assetes/admin/css/bootstrap-switch-rtl.min.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(URL::asset('assetes/admin/css/components-rounded-rtl.min.css')); ?>" rel="stylesheet" id="style_components" type="text/css" />
    <link href="<?php echo e(URL::asset('assetes/admin/css/plugins-rtl.min.')); ?>" rel="stylesheet" type="text/css" />
    <!-- END THEME GLOBAL STYLES -->
    <!-- BEGIN THEME LAYOUT STYLES -->
    <link href="<?php echo e(URL::asset('assetes/admin/css/layout-rtl.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(URL::asset('assetes/admin/css/themes/darkblue-rtl.min.css')); ?>" rel="stylesheet" type="text/css" id="style_color" />
    <link href="<?php echo e(URL::asset('assetes/admin/css/custom-rtl.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="/admin/home">لوحة التحكم</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="<?php echo e(url('/admin/roles')); ?>">مجموعات المشرفين</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>مجموعات المشرفين</span>
            </li>
        </ul>
    </div>

    <h1 class="page-title"> إضافة مجموعة مشرفين
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session()->has('msg')): ?>

        <p class="alert alert-success" style="width: 100%">

            <?php echo e(session()->get('msg')); ?>


        </p>

    <?php endif; ?>


    <form class="form-horizontal" method="post" action="<?php echo e(url('/admin/roles')); ?>">
        <?php echo e(csrf_field()); ?>


        <div class="row">
            <div class="col-lg-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption font-red-sunglo">
                            <i class="icon-settings font-red-sunglo"></i>
                            <span class="caption-subject bold uppercase"> مجموعات المشرفين </span>

                        </div>
                        <br><br><br>
                        <span class="caption-subject bold uppercase"> مجموعة جديدة </span>
                    </div>
                    <div class="portlet-body form">
                        <div class="btn-group"></div>

                        <div class="form-group">
                            <label for="role_name" class="col-lg-3 control-label">اسم المجموعة</label>
                            <div class="col-lg-6">
                                <input id="role_name" name="role_name" type="text" class="form-control" placeholder="اسم المجموعة">
                            </div>
                        </div>
                        <br>
                        <hr>
                        <br>
                        <?php
                            $admins = [];
                            $contacts = [];

                            $roles = [];$settings = [];$social_settings = [];
                            $important_links = [];
                            $pages =[];
                        ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($value->table_name === 'admins'): ?>
                                <?php array_push($admins, ['permission_name' => $value->permission_name, 'id' => $value->id]) ?>
                            <?php endif; ?>



                            <?php if($value->table_name === 'roles'): ?>
                                <?php array_push($roles, ['permission_name' => $value->permission_name, 'id' => $value->id]) ?>
                            <?php endif; ?>
                            <?php if($value->table_name === 'settings'): ?>
                                <?php array_push($settings, ['permission_name' => $value->permission_name, 'id' => $value->id]) ?>
                            <?php endif; ?>
                            <?php if($value->table_name === 'social_settings'): ?>
                                    <?php array_push($social_settings, ['permission_name' => $value->permission_name, 'id' => $value->id]) ?>
                            <?php endif; ?>
                            <?php if($value->table_name === 'pages'): ?>
                                <?php array_push($pages, ['permission_name' => $value->permission_name, 'id' => $value->id]) ?>
                            <?php endif; ?>
                            <?php if($value->table_name === 'important_links'): ?>
                                <?php array_push($important_links, ['permission_name' => $value->permission_name, 'id' => $value->id]) ?>
                            <?php endif; ?>
                            <?php if($value->table_name === 'contacts'): ?>
                                <?php array_push($contacts, ['permission_name' => $value->permission_name, 'id' => $value->id]) ?>
                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group form-md-checkboxes">
                            <label class="col-md-12"><?php echo app('translator')->getFromJson('permissions.admins'); ?></label>
                            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="md-checkbox col-md-3">
                                <input type="checkbox" id="<?php echo e($item['id']); ?>" name="permission[]" class="md-check" value="<?php echo e($item['id']); ?>">
                                <label for="<?php echo e($item['id']); ?>">
                                    <span></span>
                                    <span class="check"></span>
                                    <span class="box"></span> <?php echo app('translator')->getFromJson('permissions.' . $item['permission_name']); ?></label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>



                        <hr>
                        <div class="form-group form-md-checkboxes">
                            <label class="col-md-12"><?php echo app('translator')->getFromJson('permissions.settings'); ?></label>
                            <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="md-checkbox col-md-3">
                                    <input type="checkbox" id="<?php echo e($item['id']); ?>" name="permission[]" class="md-check" value="<?php echo e($item['id']); ?>">
                                    <label for="<?php echo e($item['id']); ?>">
                                        <span></span>
                                        <span class="check"></span>
                                        <span class="box"></span> <?php echo app('translator')->getFromJson('permissions.' . $item['permission_name']); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <hr>
                        <div class="form-group form-md-checkboxes">
                            <label class="col-md-12"><?php echo app('translator')->getFromJson('permissions.social_settings'); ?></label>
                            <?php $__currentLoopData = $social_settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="md-checkbox col-md-3">
                                    <input type="checkbox" id="<?php echo e($item['id']); ?>" name="permission[]" class="md-check" value="<?php echo e($item['id']); ?>">
                                    <label for="<?php echo e($item['id']); ?>">
                                        <span></span>
                                        <span class="check"></span>
                                        <span class="box"></span> <?php echo app('translator')->getFromJson('permissions.' . $item['permission_name']); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <hr>
                        <div class="form-group form-md-checkboxes">
                            <label class="col-md-12"><?php echo app('translator')->getFromJson('permissions.pages'); ?></label>
                            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="md-checkbox col-md-3">
                                    <input type="checkbox" id="<?php echo e($item['id']); ?>" name="permission[]" class="md-check" value="<?php echo e($item['id']); ?>">
                                    <label for="<?php echo e($item['id']); ?>">
                                        <span></span>
                                        <span class="check"></span>
                                        <span class="box"></span> <?php echo app('translator')->getFromJson('permissions.' . $item['permission_name']); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <hr>
                        <div class="form-group form-md-checkboxes">
                            <label class="col-md-12"><?php echo app('translator')->getFromJson('permissions.important_links'); ?></label>
                            <?php $__currentLoopData = $important_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="md-checkbox col-md-3">
                                    <input type="checkbox" id="<?php echo e($item['id']); ?>" name="permission[]" class="md-check" value="<?php echo e($item['id']); ?>">
                                    <label for="<?php echo e($item['id']); ?>">
                                        <span></span>
                                        <span class="check"></span>
                                        <span class="box"></span> <?php echo app('translator')->getFromJson('permissions.' . $item['permission_name']); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>



                        <hr>
                        <div class="form-group form-md-checkboxes">
                            <label class="col-md-12"><?php echo app('translator')->getFromJson('permissions.contacts'); ?></label>
                            <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="md-checkbox col-md-3">
                                    <input type="checkbox" id="<?php echo e($item['id']); ?>" name="permission[]" class="md-check" value="<?php echo e($item['id']); ?>">
                                    <label for="<?php echo e($item['id']); ?>">
                                        <span></span>
                                        <span class="check"></span>
                                        <span class="box"></span> <?php echo app('translator')->getFromJson('permissions.' . $item['permission_name']); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>


                        <div class="form-group form-md-checkboxes">
                            <label class="col-md-12"><?php echo app('translator')->getFromJson('permissions.roles'); ?></label>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="md-checkbox col-md-3">
                                    <input type="checkbox" id="<?php echo e($item['id']); ?>" name="permission[]" class="md-check" value="<?php echo e($item['id']); ?>">
                                    <label for="<?php echo e($item['id']); ?>">
                                        <span></span>
                                        <span class="check"></span>
                                        <span class="box"></span> <?php echo app('translator')->getFromJson('permissions.' . $item['permission_name']); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>


                        <div class="form-actions">
                            <div class="row">
                                <div class="col-lg-2 col-lg-offset-10">
                                    
                                    <input class="btn green btn-block" type="submit" value="حفظ" onclick="this.disabled=true;this.value='تم الارسال, انتظر...';this.form.submit();" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('assetes/admin/js/datatable.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assetes/admin/js/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assetes/admin/js/datatables.bootstrap.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assetes/admin/js/table-datatables-managed.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assetes/admin/js/sweetalert.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assetes/admin/js/ui-sweetalert.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assetes/admin/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assetes/admin/js/components-select2.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assetes/admin/js/bootstrap-fileinput.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assetes/admin/js/layout.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assetes/admin/js/demo.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assetes/admin/js/quick-sidebar.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assetes/admin/js/quick-nav.min.js')); ?>"></script>
    
        
        
            
            
                
            
        
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\orderMosb2a\resources\views/admin/admins/groups/create.blade.php ENDPATH**/ ?>