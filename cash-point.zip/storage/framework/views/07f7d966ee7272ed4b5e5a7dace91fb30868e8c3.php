<?php $__env->startSection('title'); ?>
    تعديل حالة العمولة
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/datatables.bootstrap-rtl.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/sweetalert.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/sweetalert.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="/admin/home">لوحة التحكم</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                تعديل حالة العمولة
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>عرض تعديل حالة العمولة</span>
            </li>
        </ul>
    </div>

    <h1 class="page-title">عرض تعديل حالة العمولة
        <small>عرض تعديل حالة العمولة</small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session('msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session('msg')); ?>

        </div>
    <?php endif; ?>

    <div class="row">

        <div class="col-md-8">
            <!-- BEGIN TAB PORTLET-->
            <form method="post" action="/admin/update/commission/<?php echo e($offers->id); ?>" enctype="multipart/form-data">
                <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>


                <!-- BEGIN CONTENT -->
                <div class="page-content-wrapper">
                    <!-- BEGIN CONTENT BODY -->
                    <div class="row">
                        <!-- BEGIN SAMPLE FORM PORTLET-->
                        <div class="portlet light bordered table-responsive">
                            <div class="portlet-body form">
                                <div class="form-horizontal" role="form">

                                    <div class="form-group">
                                        <label for="gender" class="col-md-3 control-label">اختر الحالة</label>
                                        <div class="col-lg-9">
                                            <div class=" input-group select2-bootstrap-append">
                                                <select  name="status" class="form-control select2-allow-clear">

                                                    <option value="2" <?php echo e($offers->active ==2 ? 'selected' : ''); ?>>لما يتم الدفع</option>
                                                    <option value="1" <?php echo e($offers->active ==1 ? 'selected' : ''); ?>>تم الدفع</option>


                                                </select>

                                                <span class="input-group-btn">
                                                        <button class="btn btn-default" type="button" data-select2-open="single-append-text">
                                                            <span class="glyphicon glyphicon-search"></span>
                                                        </button>
                                                    </span>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- END SAMPLE FORM PORTLET-->


                    </div>


                    <!-- END CONTENT BODY -->
                </div>
                <!-- END CONTENT -->



                <div class="form-actions">
                    <div class="row">
                        <div class="col-md-offset-3 col-md-9">
                            <button type="submit" class="btn green">حفظ</button>
                        </div>
                    </div>
                </div>
            </form>
            <!-- END TAB PORTLET-->





        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('admin/js/datatable.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/datatables.bootstrap.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/table-datatables-managed.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/sweetalert.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/ui-sweetalert.min.js')); ?>"></script>
    <script>

        firebase.database().ref('AdminNotificationsAcceptAds').remove();
        $(document).ready(function() {
            var CSRF_TOKEN = $('meta[name="X-CSRF-TOKEN"]').attr('content');

            $('body').on('click', '.delete_offer', function() {
                var id = $(this).attr('data');

                var swal_text = 'حذف ' + $(this).attr('data_name') + '؟';
                var swal_title = 'هل أنت متأكد من الحذف ؟';

                swal({
                    title: swal_title,
                    text: swal_text,
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonClass: "btn-warning",
                    confirmButtonText: "تأكيد",
                    cancelButtonText: "إغلاق",
                    closeOnConfirm: false
                }, function() {

                    window.location.href = "<?php echo e(url('/')); ?>" + "/admin/delete/"+id+"/checkCenter";


                });

            });

        });


    </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sawaq\resources\views/admin/orders/edit_commission.blade.php ENDPATH**/ ?>