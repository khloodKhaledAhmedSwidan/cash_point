<?php $__env->startSection('title'); ?>
    تعديل مستخدم
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/select2-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/bootstrap-fileinput.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="/admin/home">لوحة التحكم</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="/admin/user/1">المستخدمين</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>تعديل المستخدمين</span>
            </li>
        </ul>
    </div>

    <h1 class="page-title"> المستخدمين
        <small>تعديل المستخدمين</small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <?php if(session('information')): ?>
        <div class="alert alert-success">
            <?php echo e(session('information')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('pass')): ?>
        <div class="alert alert-success">
            <?php echo e(session('pass')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('privacy')): ?>
        <div class="alert alert-success">
            <?php echo e(session('privacy')); ?>

        </div>
    <?php endif; ?>
    <?php if(count($errors)): ?>
        <ul class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
    <!-- END PAGE TITLE-->
    <!-- END PAGE HEADER-->
    <div class="row">
        <div class="col-md-12">

            <!-- BEGIN PROFILE CONTENT -->
            <div class="profile-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="portlet light ">
                            <div class="portlet-title tabbable-line">
                                <div class="caption caption-md">
                                    <i class="icon-globe theme-font hide"></i>
                                    <span class="caption-subject font-blue-madison bold uppercase">حساب الملف الشخصي</span>
                                </div>
                                <ul class="nav nav-tabs">
                                    <li class="active">
                                        <a href="#tab_1_1" data-toggle="tab">المعلومات الشخصية</a>
                                    </li>

                                    <li>
                                        <a href="#tab_1_3" data-toggle="tab">تغيير كلمة المرور</a>
                                    </li>
                                    <li>
                                        <a href="#tab_1_4" data-toggle="tab">اعدادات الخصوصية</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="portlet-body">
                                <div class="tab-content">
                                    <!-- PERSONAL INFO TAB -->
                                    <div class="tab-pane active" id="tab_1_1">
                                        <form role="form" action="/admin/update/user/<?php echo e($user->id); ?>/1" method="post" enctype="multipart/form-data">
                                            <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                                            <div class="form-group">
                                                <label class="control-label">الاسم</label>
                                                <input type="text" name="name" placeholder="الاسم" class="form-control" value="<?php echo e($user->name); ?>" />
                                                <?php if($errors->has('name')): ?>
                                                    <span class="help-block">
                                                       <strong style="color: red;"><?php echo e($errors->first('name')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>


                                            <div class="form-group">
                                                <label class="control-label">رقم الهاتف</label>
                                                <input type="text" name="phone_number" placeholder="رقم الهاتف" class="form-control" value="<?php echo e($user->phone_number); ?>" />
                                                <?php if($errors->has('phone_number')): ?>
                                                    <span class="help-block">
                                                       <strong style="color: red;"><?php echo e($errors->first('phone_number')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>


                                            <div class="form-body">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-3">الصورة الشخصية</label>
                                                    <div class="col-md-9">
                                                        <div class="fileinput fileinput-new" data-provides="fileinput">
                                                            <div class="fileinput-preview thumbnail" data-trigger="fileinput" style="width: 200px; height: 150px;">
                                                                <?php if($user->image !==null): ?>
                                                                    <img   src='<?php echo e(asset("uploads/users/$user->image")); ?>'>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div>
                                                            <span class="btn red btn-outline btn-file">
                                                                <span class="fileinput-new"> اختر الصورة </span>
                                                                <span class="fileinput-exists"> تغيير </span>
                                                                <input type="file" name="image"> </span>
                                                                <a href="javascript:;" class="btn red fileinput-exists" data-dismiss="fileinput"> إزالة </a>



                                                            </div>
                                                        </div>
                                                        <?php if($errors->has('image')): ?>
                                                            <span class="help-block">
                                                               <strong style="color: red;"><?php echo e($errors->first('image')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>

                                                </div>
                                            </div>

                                            <div class="form-body">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-3">صورة السيارة</label>
                                                    <div class="col-md-9">
                                                        <div class="fileinput fileinput-new" data-provides="fileinput">
                                                            <div class="fileinput-preview thumbnail" data-trigger="fileinput" style="width: 200px; height: 150px;">
                                                                <?php if($user->car_image !==null): ?>
                                                                    <img   src='<?php echo e(asset("uploads/users/$user->car_image")); ?>'>
                                                                <?php endif; ?>
                                                            </div>

                                                            <div>
                                                            <span class="btn red btn-outline btn-file">
                                                                <span class="fileinput-new"> اختر الصورة </span>
                                                                <span class="fileinput-exists"> تغيير </span>
                                                                <input type="file" name="car_image"> </span>
                                                                <a href="javascript:;" class="btn red fileinput-exists" data-dismiss="fileinput"> إزالة </a>



                                                            </div>
                                                        </div>
                                                        <?php if($errors->has('car_image')): ?>
                                                            <span class="help-block">
                                                               <strong style="color: red;"><?php echo e($errors->first('car_image')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>

                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="gender" class="control-label">السائق</label>

                                                <div class=" input-group select2-bootstrap-append">
                                                    <select  name="driver_id"  class="form-control select2-allow-clear">
                                                        <option value>اختر السائق</option>
                                                        <?php $__currentLoopData = \App\Driver::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <option value="<?php echo e($country->id); ?>" <?php echo e($user->driver_id == $country->id ? 'selected' : ''); ?>><?php echo e($country->name); ?></option>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </select>
                                                    <?php if($errors->has('driver_id')): ?>
                                                        <span class="help-block">
                                                               <strong style="color: red;"><?php echo e($errors->first('driver_id')); ?></strong>
                                                            </span>
                                                    <?php endif; ?>
                                                    <span class="input-group-btn">
                                                        <button class="btn btn-default" type="button" data-select2-open="single-append-text">
                                                            <span class="glyphicon glyphicon-search"></span>
                                                        </button>
                                                    </span>
                                                </div>

                                            </div>
                                            <div class="form-group">
                                                <label for="gender" class="control-label">الجنسية</label>

                                                <div class=" input-group select2-bootstrap-append">
                                                    <select  name="nationality_id"  class="form-control select2-allow-clear">
                                                        <option value>اختر الجنسية</option>
                                                        <?php $__currentLoopData = \App\Nationality::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <option value="<?php echo e($country->id); ?>" <?php echo e($user->nationality_id == $country->id ? 'selected' : ''); ?>><?php echo e($country->name); ?></option>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </select>
                                                    <?php if($errors->has('nationality_id')): ?>
                                                        <span class="help-block">
                                                               <strong style="color: red;"><?php echo e($errors->first('nationality_id')); ?></strong>
                                                            </span>
                                                    <?php endif; ?>
                                                    <span class="input-group-btn">
                                                        <button class="btn btn-default" type="button" data-select2-open="single-append-text">
                                                            <span class="glyphicon glyphicon-search"></span>
                                                        </button>
                                                    </span>
                                                </div>

                                            </div>
                                            <div class="form-group">
                                                <label for="gender" class="control-label">العمر</label>

                                                <div class=" input-group select2-bootstrap-append">
                                                    <select  name="age_id"  class="form-control select2-allow-clear">
                                                        <option value>اختر العمر</option>
                                                        <?php $__currentLoopData = \App\Age::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <option value="<?php echo e($country->id); ?>" <?php echo e($user->age_id == $country->id ? 'selected' : ''); ?>><?php echo e($country->number); ?></option>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </select>
                                                    <?php if($errors->has('age_id')): ?>
                                                        <span class="help-block">
                                                               <strong style="color: red;"><?php echo e($errors->first('age_id')); ?></strong>
                                                            </span>
                                                    <?php endif; ?>
                                                    <span class="input-group-btn">
                                                        <button class="btn btn-default" type="button" data-select2-open="single-append-text">
                                                            <span class="glyphicon glyphicon-search"></span>
                                                        </button>
                                                    </span>
                                                </div>

                                            </div>
                                            <div class="form-group">
                                                <label for="gender" class="control-label">الشركة المصنعة</label>

                                                <div class=" input-group select2-bootstrap-append">
                                                    <select  name="company_id"  class="form-control select2-allow-clear">
                                                        <option value>اختر الشركة المصنعة</option>
                                                        <?php $__currentLoopData = \App\Company::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <option value="<?php echo e($country->id); ?>" <?php echo e($user->company_id == $country->id ? 'selected' : ''); ?>><?php echo e($country->name); ?></option>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </select>
                                                    <?php if($errors->has('company_id')): ?>
                                                        <span class="help-block">
                                                               <strong style="color: red;"><?php echo e($errors->first('company_id')); ?></strong>
                                                            </span>
                                                    <?php endif; ?>
                                                    <span class="input-group-btn">
                                                        <button class="btn btn-default" type="button" data-select2-open="single-append-text">
                                                            <span class="glyphicon glyphicon-search"></span>
                                                        </button>
                                                    </span>
                                                </div>

                                            </div>
                                            <div class="form-group">
                                                <label for="gender" class="control-label">الموديل</label>

                                                <div class=" input-group select2-bootstrap-append">
                                                    <select  name="car_model_id"  class="form-control select2-allow-clear">
                                                        <option value>اختر الموديل</option>
                                                        <?php $__currentLoopData = \App\CarModel::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <option value="<?php echo e($country->id); ?>" <?php echo e($user->car_model_id == $country->id ? 'selected' : ''); ?>><?php echo e($country->name); ?></option>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </select>
                                                    <?php if($errors->has('car_model_id')): ?>
                                                        <span class="help-block">
                                                               <strong style="color: red;"><?php echo e($errors->first('car_model_id')); ?></strong>
                                                            </span>
                                                    <?php endif; ?>
                                                    <span class="input-group-btn">
                                                        <button class="btn btn-default" type="button" data-select2-open="single-append-text">
                                                            <span class="glyphicon glyphicon-search"></span>
                                                        </button>
                                                    </span>
                                                </div>

                                            </div>
                                            <div class="form-group">
                                                <label for="gender" class="control-label">سنة الموديل</label>

                                                <div class=" input-group select2-bootstrap-append">
                                                    <select  name="city_mode_id"  class="form-control select2-allow-clear">
                                                        <option value>اختر سنة الموديل</option>
                                                        <?php $__currentLoopData = \App\ModelCity::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <option value="<?php echo e($country->id); ?>" <?php echo e($user->city_mode_id == $country->id ? 'selected' : ''); ?>><?php echo e($country->year); ?></option>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </select>
                                                    <?php if($errors->has('city_mode_id')): ?>
                                                        <span class="help-block">
                                                               <strong style="color: red;"><?php echo e($errors->first('city_mode_id')); ?></strong>
                                                            </span>
                                                    <?php endif; ?>
                                                    <span class="input-group-btn">
                                                        <button class="btn btn-default" type="button" data-select2-open="single-append-text">
                                                            <span class="glyphicon glyphicon-search"></span>
                                                        </button>
                                                    </span>
                                                </div>

                                            </div>
                                            <div class="form-group">
                                                <label for="gender" class="control-label">عدد الركاب</label>

                                                <div class=" input-group select2-bootstrap-append">
                                                    <select  name="passenger_id"  class="form-control select2-allow-clear">
                                                        <option value>اختر عدد الركاب</option>
                                                        <?php $__currentLoopData = \App\Passenger::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <option value="<?php echo e($country->id); ?>" <?php echo e($user->passenger_id == $country->id ? 'selected' : ''); ?>><?php echo e($country->number); ?></option>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </select>
                                                    <?php if($errors->has('passenger_id')): ?>
                                                        <span class="help-block">
                                                               <strong style="color: red;"><?php echo e($errors->first('passenger_id')); ?></strong>
                                                            </span>
                                                    <?php endif; ?>
                                                    <span class="input-group-btn">
                                                        <button class="btn btn-default" type="button" data-select2-open="single-append-text">
                                                            <span class="glyphicon glyphicon-search"></span>
                                                        </button>
                                                    </span>
                                                </div>

                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-3 control-label">توصيل الجامعات</label>
                                                <div class="col-md-9">
                                                    <div class="mt-radio-inline">
                                                        <label class="mt-radio">
                                                            <input type="radio" name="university_drive"  value="0" <?php echo e($user->university_drive == 0 ? 'checked' : ''); ?>>  لا
                                                            <span></span>
                                                        </label>
                                                        <label class="mt-radio">
                                                            <input type="radio" name="university_drive"  value="1" <?php echo e($user->university_drive == 1 ? 'checked' : ''); ?>> نعم
                                                            <span></span>
                                                        </label>


                                                    </div>
                                                    <?php if($errors->has('university_drive')): ?>
                                                        <span class="help-block">
                                                           <strong style="color: red;"><?php echo e($errors->first('university_drive')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-3 control-label">توصيل موظفات</label>
                                                <div class="col-md-9">
                                                    <div class="mt-radio-inline">
                                                        <label class="mt-radio">
                                                            <input type="radio" name="employees_drive"  value="0" <?php echo e($user->employees_drive == 0 ? 'checked' : ''); ?>>  لا
                                                            <span></span>
                                                        </label>
                                                        <label class="mt-radio">
                                                            <input type="radio" name="employees_drive"  value="1" <?php echo e($user->employees_drive == 1 ? 'checked' : ''); ?>> نعم
                                                            <span></span>
                                                        </label>


                                                    </div>
                                                    <?php if($errors->has('employees_drive')): ?>
                                                        <span class="help-block">
                                                           <strong style="color: red;"><?php echo e($errors->first('employees_drive')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="gender" class="control-label">اختر المدينة</label>

                                                <div class=" input-group select2-bootstrap-append">
                                                    <select  name="city_id" id="choose_country" class="form-control select2-allow-clear" id="country">
                                                        <option value>اختر المدينة</option>
                                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($country->parent_id == null): ?>
                                                                <option value="<?php echo e($country->id); ?>" <?php echo e($user->city_id == $country->id ? 'selected' : ''); ?>><?php echo e($country->name); ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </select>
                                                    <?php if($errors->has('city_id')): ?>
                                                        <span class="help-block">
                                                               <strong style="color: red;"><?php echo e($errors->first('city_id')); ?></strong>
                                                            </span>
                                                    <?php endif; ?>
                                                    <span class="input-group-btn">
                                                        <button class="btn btn-default" type="button" data-select2-open="single-append-text">
                                                            <span class="glyphicon glyphicon-search"></span>
                                                        </button>
                                                    </span>
                                                </div>

                                            </div>

                                            <div class="form-group" >
                                                <label for="gender" class="control-label">اختر الحي</label>

                                                <div class=" input-group select2-bootstrap-append">
                                                    <select  name="region_id" id="choose_region" class="form-control select2-allow-clear" id="register_city">
                                                        <option value>اختر الحي</option>
                                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($country->parent_id !== null): ?>
                                                                <option value="<?php echo e($country->id); ?>" <?php echo e($user->region_id == $country->id ? 'selected' : ''); ?>><?php echo e($country->name); ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php if($errors->has('region_id')): ?>
                                                        <span class="help-block">
                                                               <strong style="color: red;"><?php echo e($errors->first('region_id')); ?></strong>
                                                            </span>
                                                    <?php endif; ?>
                                                    <span class="input-group-btn">
                                                        <button class="btn btn-default" type="button" data-select2-open="single-append-text">
                                                            <span class="glyphicon glyphicon-search"></span>
                                                        </button>
                                                    </span>
                                                </div>

                                            </div>

                                            <div class="form-group">
                                                <label class="col-md-3 control-label">توصيل اكثر من موقع</label>
                                                <div class="col-md-9">
                                                    <div class="mt-radio-inline">
                                                        <label class="mt-radio">
                                                            <input type="radio" name="multi_place"  value="0" <?php echo e($user->multi_place == 0 ? 'checked' : ''); ?>>  لا
                                                            <span></span>
                                                        </label>
                                                        <label class="mt-radio">
                                                            <input type="radio" name="multi_place"  value="1" <?php echo e($user->multi_place == 1 ? 'checked' : ''); ?>> نعم
                                                            <span></span>
                                                        </label>


                                                    </div>
                                                    <?php if($errors->has('multi_place')): ?>
                                                        <span class="help-block">
                                                           <strong style="color: red;"><?php echo e($errors->first('multi_place')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="form-group" id="multi_placce">
                                                <div  <?php if($user->places !== null): ?> style="display: block;" <?php else: ?>  style="display: none;"  <?php endif; ?>>
                                                <label for="gender" class="control-label">اختر الحي</label>

                                                <div class=" input-group select2-bootstrap-append">
                                                    <select  name="places" id="places" class="form-control select2-allow-clear">
                                                        <option value>اختر الحي</option>

                                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($country->parent_id !== null): ?>
                                                                    <option value="<?php echo e($country->id); ?>" <?php echo e($user->places == $country->id ? 'selected' : ''); ?>><?php echo e($country->name); ?></option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                    </select>
                                                    <?php if($errors->has('places')): ?>
                                                        <span class="help-block">
                                                               <strong style="color: red;"><?php echo e($errors->first('places')); ?></strong>
                                                            </span>
                                                    <?php endif; ?>
                                                    <span class="input-group-btn">
                                                        <button class="btn btn-default" type="button" data-select2-open="single-append-text">
                                                            <span class="glyphicon glyphicon-search"></span>
                                                        </button>
                                                    </span>
                                                </div>
                                                </div>
                                            </div>






                                            <div class="margiv-top-10">
                                                <div class="form-actions">
                                                    <button type="submit" class="btn green">حفظ</button>

                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <!-- END PERSONAL INFO TAB -->

                                    <!-- CHANGE PASSWORD TAB -->
                                    <div class="tab-pane" id="tab_1_3">
                                        <form action="/admin/update/pass/<?php echo e($user->id); ?>" method="post">
                                            <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>

                                            <div class="form-group">
                                                <label class="control-label">كلمة المرور الجديدة</label>
                                                <input type="password" name="password" class="form-control" />
                                                <?php if($errors->has('password')): ?>
                                                    <span class="help-block">
                                                       <strong style="color: red;"><?php echo e($errors->first('password')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label">إعادة كلمة المرور</label>
                                                <input type="password" name="password_confirmation" class="form-control" />
                                                <?php if($errors->has('password_confirmation')): ?>
                                                    <span class="help-block">
                                                       <strong style="color: red;"><?php echo e($errors->first('password_confirmation')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="margin-top-10">
                                                <div class="form-actions">
                                                    <button type="submit" class="btn green">حفظ</button>

                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <!-- END CHANGE PASSWORD TAB -->
                                    <!-- PRIVACY SETTINGS TAB -->
                                    <div class="tab-pane" id="tab_1_4">
                                        <form action="/admin/update/privacy/<?php echo e($user->id); ?>" method="post">
                                            <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                                            <table class="table table-light table-hover">

                                                <tr>
                                                    <td> تفعيل المستخدم</td>
                                                    <td>
                                                        <div class="mt-radio-inline">
                                                            <label class="mt-radio">
                                                                <input type="radio" name="active" value="1" <?php echo e($user->active == "1" ? 'checked' : ''); ?>/> نعم
                                                                <span></span>
                                                            </label>
                                                            <label class="mt-radio">
                                                                <input type="radio" name="active" value="0" <?php echo e($user->active == "0" ? 'checked' : ''); ?>/> لا
                                                                <span></span>
                                                            </label>
                                                            <?php if($errors->has('active')): ?>
                                                                <span class="help-block">
                                                                       <strong style="color: red;"><?php echo e($errors->first('active')); ?></strong>
                                                                    </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                </tr>


                                            </table>
                                            <div class="margin-top-10">
                                                <div class="form-actions">
                                                    <button type="submit" class="btn green">حفظ</button>

                                                </div>
                                            </div>
                                        </form>

                                    </div>
                                    <!-- END PRIVACY SETTINGS TAB -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END PROFILE CONTENT -->
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('admin/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/components-select2.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/bootstrap-fileinput.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            // for get regions
            $('select[name="city_id"]').on('change', function() {
                var id = $(this).val();
                if (id) {
                    $.ajax({
                        url: '/admin/get/regions/' + id,
                        type: "GET",
                        dataType: "json",
                        success: function (data) {
                            $('#choose_region').empty();
                            $('#places').empty();
                            $('#choose_city').empty();

                            $('select[name="c"]').append('<option value>اختر المنطقة</option>');
                            $.each(data['regions'], function (index, regions) {

                                $('select[name="region_id"]').append('<option value="' + regions.id + '">' + regions.name + '</option>');

                            });
                            $('select[name="places"]').append('<option value>اختر المنطقة</option>');
                            $.each(data['regions'], function (index, regions) {

                                $('select[name="places"]').append('<option value="' + regions.id + '">' + regions.name + '</option>');

                            });


                        }
                    });
                }else{
                    $('#choose_region').empty();
                    $('#places').empty();
                    $('#choose_city').empty();
                }
            });


            $( "body" ).on( "change", "input[type=radio][name=multi_place]", function() {
                // $( this ).after( "<p>Another paragraph! " + (++count) + "</p>" );

                all_payment_status = $(this).val();
                var id = $(this).val();
                if (id == "1") {

                    $('#multi_placce').show();



                }else{
                    $('#multi_placce').hide();


                }


            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sawaq\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>
