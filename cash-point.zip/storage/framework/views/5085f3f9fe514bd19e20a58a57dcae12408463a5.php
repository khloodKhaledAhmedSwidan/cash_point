<?php $__env->startSection('title'); ?>
    العمر
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="/admin/home">لوحة التحكم</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="/admin/age">العمر</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>اضافة العمر</span>
            </li>
        </ul>
    </div>

    <h1 class="page-title">العمر
        <small>اضافة العمر</small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-md-8">
            <!-- BEGIN TAB PORTLET-->
            <form method="post" action="/admin/add/age" enctype="multipart/form-data">
                <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>




                        <!-- BEGIN CONTENT -->

                            <!-- BEGIN CONTENT BODY -->
                            <div class="row">
                                <!-- BEGIN SAMPLE FORM PORTLET-->
                                <div class="portlet light bordered table-responsive">
                                    <div class="portlet-body form">
                                        <div class="form-horizontal" role="form">

                                            <div class="form-group">
                                                <label class="col-md-3 control-label">العمر</label>
                                                <div class="col-md-9">
                                                    <input type="text" name="number" class="form-control" placeholder="العمر" value="<?php echo e(old('number')); ?>">
                                                    <?php if($errors->has('number')): ?>
                                                        <span class="help-block">
                                                           <strong style="color: red;"><?php echo e($errors->first('number')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>



                                        </div>
                                    </div>
                                </div>
                                <!-- END SAMPLE FORM PORTLET-->


                            </div>


                            <!-- END CONTENT BODY -->

                        <!-- END CONTENT -->



                <div class="form-actions">
                    <div class="row">
                        <div class="col-md-offset-3 col-md-9">
                            <button type="submit" class="btn green" value="حفظ" onclick="this.disabled=true;this.value='تم الارسال, انتظر...';this.form.submit();">حفظ</button>
                        </div>
                    </div>
                </div>
            </form>
            <!-- END TAB PORTLET-->





        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>

            function loadScript(src,callback){

                var script = document.createElement("script");
                script.type = "text/javascript";
                if(callback)script.onload=callback;
                document.getElementsByTagName("head")[0].appendChild(script);
                script.src = src;
            }


            loadScript('http://maps.googleapis.com/maps/api/js?key=AIzaSyA9UeezZ2xyNjrwck8SLdh9NxsJp6HhLQc&callback=initialize',
                function(){
                    // log('google-loader has been loaded, but not the maps-API ');
                });


            function initialize() {

                // log('maps-API has been loaded, ready to use');
                var map = new google.maps.Map(document.getElementById('map_canvas'), {
                    zoom: 5,
                    center: new google.maps.LatLng(23.8859425,45.0791626),
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                });

                var myMarker = new google.maps.Marker({
                    position: new google.maps.LatLng(23.8859425 ,45.0791626),
                    draggable: true
                });

                google.maps.event.addListener(myMarker, 'dragend', function (evt) {
                    document.getElementById('current').innerHTML = '<p>Marker dropped: Current Lat: ' + evt.latLng.lat()+ ' Current Lng: ' + evt.latLng.lng() + '</p>';
                    document.getElementById("latitude").value =evt.latLng.lat();
                    document.getElementById("longitude").value =evt.latLng.lng();
                });

                google.maps.event.addListener(myMarker, 'dragstart', function (evt) {
                    document.getElementById('current').innerHTML = '<p>Currently dragging marker...</p>';
                });

                map.setCenter(myMarker.position);
                myMarker.setMap(map);
            }

            function log(str){
                document.getElementsByTagName('pre')[0].appendChild(document.createTextNode('['+new Date().getTime()+']\n'+str+'\n\n'));
            }

            /* for user type in register*/
            $(document).ready(function() {

                // for get regions
                $('select[name="country"]').on('change', function() {
                    var id = $(this).val();
                    if (id) {
                        $.ajax({
                            url: '/get/regions/' + id,
                            type: "GET",
                            dataType: "json",
                            success: function (data) {
                                $('#choose_region').empty();
                                $('#choose_city').empty();

                                $('select[name="region"]').append('<option value>اختر المنطقة</option>');
                                $.each(data['regions'], function (index, regions) {

                                    $('select[name="region"]').append('<option value="' + regions.id + '">' + regions.name + '</option>');

                                });


                            }
                        });
                    }else{
                        $('#choose_region').empty();
                        $('#choose_city').empty();
                    }
                });
                // for get cities
                $('select[name="region"]').on('change', function() {
                    var id = $(this).val();
                    if (id){
                        $.ajax({
                            url: '/get/cities/'+id,
                            type: "GET",
                            dataType: "json",
                            success:function(data) {
                                $('#choose_city').empty();

                                $('select[name="city"]').append('<option value>اختر المدينة</option>');
                                $.each(data['cities'], function(index , cities) {

                                    $('select[name="city"]').append('<option value="'+ cities.id +'">'+cities.name+'</option>');

                                });


                            }
                        });
                    }else{
                        $('#choose_city').empty();
                    }
                });


            });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sawaq\resources\views/admin/ages/create.blade.php ENDPATH**/ ?>