<?php $__env->startSection('title'); ?>
    اضافة قسم
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/select2-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/bootstrap-fileinput.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="/admin/home">لوحة التحكم</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="<?php echo e(url('/admin/categories')); ?>">الاقسام</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>اضافة قسم</span>
            </li>
        </ul>
    </div>

    <h1 class="page-title"> الاقسام
        <small>اضافة قسم</small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



    <!-- END PAGE TITLE-->
    <!-- END PAGE HEADER-->
    <div class="row">
        <div class="col-md-12">

            <!-- BEGIN PROFILE CONTENT -->
            <div class="profile-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="portlet light ">
      
                            <form role="form" action="<?php echo e(route('categories.store')); ?>" method="post" enctype="multipart/form-data">
                   
                                <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                                <div class="portlet-body">

                                    <div class="tab-content">
                                        <!-- PERSONAL INFO TAB -->
                                        <div class="tab-pane active" id="tab_1_1">


                                            <div class="form-group">
                                                <label class="control-label">اسم القسم</label>
                                                <input type="text" name="name" placeholder="اسم القسم" class="form-control" value="<?php echo e(old('name')); ?>" />
                                                <?php if($errors->has('name')): ?>
                                                    <span class="help-block">
                                                       <strong style="color: red;"><?php echo e($errors->first('name')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>


                                            <div class="form-body">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-3">الصورة </label>
                                                    <div class="col-md-9">
                                                        <div class="fileinput fileinput-new" data-provides="fileinput">
                                                            <div class="fileinput-preview thumbnail" data-trigger="fileinput" style="width: 200px; height: 150px;">
                                                            </div>
                                                            <div>
                                                            <span class="btn red btn-outline btn-file">
                                                                <span class="fileinput-new"> اختر الصورة </span>
                                                                <span class="fileinput-exists"> تغيير </span>
                                                                <input type="file" name="image"> </span>
                                                                <a href="javascript:;" class="btn red fileinput-exists" data-dismiss="fileinput"> إزالة </a>



                                                            </div>
                                                        </div>
                                                        <?php if($errors->has('image')): ?>
                                                            <span class="help-block">
                                                               <strong style="color: red;"><?php echo e($errors->first('image')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>

                                                </div>
                                            </div>

                                        </div>
                                        <!-- END PERSONAL INFO TAB -->

                                    </div>

                                </div>
                                <div class="margiv-top-10">
                                    <div class="form-actions">
                                        <button type="submit" class="btn green" value="حفظ" onclick="this.disabled=true;this.value='تم الارسال, انتظر...';this.form.submit();">حفظ</button>

                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END PROFILE CONTENT -->
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('admin/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/components-select2.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/bootstrap-fileinput.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\TQNEE\cash-point\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>