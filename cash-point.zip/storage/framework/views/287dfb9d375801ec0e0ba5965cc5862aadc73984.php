<?php $__env->startSection('title'); ?>
    الجنسية
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="/admin/home">لوحة التحكم</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="/admin/age">الجنسية</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>اضافة الجنسية</span>
            </li>
        </ul>
    </div>

    <h1 class="page-title">الجنسية
        <small>اضافة الجنسية</small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-md-8">
            <!-- BEGIN TAB PORTLET-->
            <form method="post" action="/admin/add/nationality" enctype="multipart/form-data">
                <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>




                        <!-- BEGIN CONTENT -->

                            <!-- BEGIN CONTENT BODY -->
                            <div class="row">
                                <!-- BEGIN SAMPLE FORM PORTLET-->
                                <div class="portlet light bordered table-responsive">
                                    <div class="portlet-body form">
                                        <div class="form-horizontal" role="form">

                                            <div class="form-group">
                                                <label class="col-md-3 control-label">الجنسية</label>
                                                <div class="col-md-9">
                                                    <input type="text" name="name" class="form-control" placeholder="الجنسية" value="<?php echo e(old('name')); ?>">
                                                    <?php if($errors->has('name')): ?>
                                                        <span class="help-block">
                                                           <strong style="color: red;"><?php echo e($errors->first('name')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>



                                        </div>
                                    </div>
                                </div>
                                <!-- END SAMPLE FORM PORTLET-->


                            </div>


                            <!-- END CONTENT BODY -->

                        <!-- END CONTENT -->



                <div class="form-actions">
                    <div class="row">
                        <div class="col-md-offset-3 col-md-9">
                            <button type="submit" class="btn green" value="حفظ" onclick="this.disabled=true;this.value='تم الارسال, انتظر...';this.form.submit();">حفظ</button>
                        </div>
                    </div>
                </div>
            </form>
            <!-- END TAB PORTLET-->





        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nour\Desktop\Salamat\salam\salamat\resources\views/admin/nationalities/create.blade.php ENDPATH**/ ?>