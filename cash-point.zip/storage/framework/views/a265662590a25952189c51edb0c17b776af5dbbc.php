<?php $__env->startSection('title'); ?>
    تسجيل الدخول
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(session('An_error_occurred')): ?>
        <div class="alert alert-success">
            <?php echo e(session('An_error_occurred')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('warning_login')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('warning_login')); ?>

        </div>
    <?php endif; ?>
    <!-- BEGIN LOGIN FORM -->
    <form method="POST" action="<?php echo e(route('admin.login.submit')); ?>">
        <?php echo csrf_field(); ?>

        <h3 class="form-title font-green">تسجيل الدخول</h3>

        <div class="form-group">
            <!--ie8, ie9 does not support html5 placeholder, so we just show field title for that-->
            <label class="control-label visible-ie8 visible-ie9">االبريد الالكتروني</label>
            <input class="form-control form-control-solid placeholder-no-fix<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" type="text" autocomplete="off" placeholder="البريد الالكتروني" name="email" value="<?php echo e(old('email')); ?>"  required autofocus />
            <?php if($errors->has('email')): ?>

                <div class="alert alert-danger">
                    <button class="close" data-close="alert"></button>
                    <span> <?php echo e($errors->first('email')); ?></span>
                </div>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label class="control-label visible-ie8 visible-ie9">كلمة المرور</label>
            <input class="form-control form-control-solid placeholder-no-fix<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" type="password" autocomplete="off" placeholder="كلمة المرور" name="password" required  />
            <?php if($errors->has('password')): ?>
                <div class="alert alert-danger">
                    <button class="close" data-close="alert"></button>
                    <span> <?php echo e($errors->first('password')); ?></span>
                </div>
            <?php endif; ?>
        </div>
        
            
            

                
                    
                
            
        
        <div class="form-actions">
            <button type="submit" class="btn green uppercase">تسجيل الدخول</button>
            <label class="rememberme check mt-checkbox mt-checkbox-outline">
                <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?> />تذكرني
                <span></span>
            </label>
            <a href="<?php echo e(route('admin.password.request')); ?>"  class="forget-password">هل نسيت كلمة المرور؟</a>
        </div>


    </form>
    <!-- END LOGIN FORM -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.authAdmin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sawaq/public_html/resources/views/admin/authAdmin/login.blade.php ENDPATH**/ ?>