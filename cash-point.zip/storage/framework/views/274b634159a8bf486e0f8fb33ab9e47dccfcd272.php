<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>
<h2> <?php echo e($headingTitle); ?> </h2>
<div>
    <p>
        <span> Your Message: </span><br>
        <?php echo e($userMessage); ?>

    </p><br>
    <p>
        <span> Admin Reply: </span><br>
        <?php echo e($contactReply); ?>

    </p><br>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\orderMosb2a\resources\views/emails/contact_reply.blade.php ENDPATH**/ ?>