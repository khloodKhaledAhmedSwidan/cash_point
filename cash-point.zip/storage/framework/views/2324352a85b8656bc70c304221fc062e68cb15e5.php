<?php $__env->startSection('title'); ?>
    عدد الركاب
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="/admin/home">لوحة التحكم</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="/admin/passenger">عدد الركاب</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>اضافة عدد الركاب</span>
            </li>
        </ul>
    </div>

    <h1 class="page-title">عدد الركاب
        <small>اضافة عدد الركاب</small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-md-8">
            <!-- BEGIN TAB PORTLET-->
            <form method="post" action="/admin/add/passenger" enctype="multipart/form-data">
                <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>




                        <!-- BEGIN CONTENT -->

                            <!-- BEGIN CONTENT BODY -->
                            <div class="row">
                                <!-- BEGIN SAMPLE FORM PORTLET-->
                                <div class="portlet light bordered table-responsive">
                                    <div class="portlet-body form">
                                        <div class="form-horizontal" role="form">

                                            <div class="form-group">
                                                <label class="col-md-3 control-label">عدد الركاب</label>
                                                <div class="col-md-9">
                                                    <input type="text" name="number" class="form-control" placeholder="عدد الركاب" value="<?php echo e(old('number')); ?>">
                                                    <?php if($errors->has('number')): ?>
                                                        <span class="help-block">
                                                           <strong style="color: red;"><?php echo e($errors->first('number')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>



                                        </div>
                                    </div>
                                </div>
                                <!-- END SAMPLE FORM PORTLET-->


                            </div>


                            <!-- END CONTENT BODY -->

                        <!-- END CONTENT -->



                <div class="form-actions">
                    <div class="row">
                        <div class="col-md-offset-3 col-md-9">
                            <button type="submit" class="btn green" value="حفظ" onclick="this.disabled=true;this.value='تم الارسال, انتظر...';this.form.submit();">حفظ</button>
                        </div>
                    </div>
                </div>
            </form>
            <!-- END TAB PORTLET-->





        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sawaq\resources\views/admin/passengers/create.blade.php ENDPATH**/ ?>