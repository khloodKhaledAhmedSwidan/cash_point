<?php $__env->startSection('title'); ?>
    إضافة بيانات الروابط
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/select2-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/bootstrap-fileinput.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="/admin/home">لوحة التحكم</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="/admin/setting/pageLinks">الروابط</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>عرض الروابط</span>
            </li>
        </ul>
    </div>

    <h1 class="page-title">عرض الروابط
        <small>إضافة بيانات الروابط</small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-md-8 ">
            <!-- BEGIN SAMPLE FORM PORTLET-->
            <div class="portlet light bordered">

                <div class="portlet-body form">
                    <form class="form-horizontal" role="form" action="/admin/add/link" method="post">
                        <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                        <div class="form-body">

                            <div class="form-group">
                                <label for="gender" class="col-md-3 control-label">اختر الصفحة</label>
                                <div class="col-lg-9">
                                    <div class=" input-group select2-bootstrap-append">
                                        <select id="gender" name="page" class="form-control select2-allow-clear">

                                            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($page->id); ?>" <?php echo e(old('page') == $page->id ? 'selected' : ''); ?>><?php echo e(unserialize($page->title)['ar']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                        <?php if($errors->has('page')): ?>
                                            <span class="help-block">
                                               <strong style="color: red;"><?php echo e($errors->first('page')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                        <span class="input-group-btn">
                                                        <button class="btn btn-default" type="button" data-select2-open="single-append-text">
                                                            <span class="glyphicon glyphicon-search"></span>
                                                        </button>
                                                    </span>
                                    </div>
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="col-md-3 control-label">المكان</label>
                                <div class="col-md-9">
                                    <div class="mt-radio-inline">
                                        <label class="mt-radio">
                                            <input type="radio" name="place"  value="header" <?php echo e(old('place') == "header" ? 'checked' : ''); ?>> أعلى الصفحة
                                            <span></span>
                                        </label>
                                        <label class="mt-radio">
                                            <input type="radio" name="place"  value="footer" <?php echo e(old('place') == "footer" ? 'checked' : ''); ?>> أسفل الصفحة
                                            <span></span>
                                        </label>
                                        <label class="mt-radio">
                                            <input type="radio" name="place"  value="both" <?php echo e(old('place') == "both" ? 'checked' : ''); ?>> معا
                                            <span></span>
                                        </label>

                                    </div>
                                    <?php if($errors->has('place')): ?>
                                        <span class="help-block">
                                               <strong style="color: red;"><?php echo e($errors->first('place')); ?></strong>
                                            </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-body">
                                <div class="form-group">
                                    <label class="col-md-3 control-label">ترتيب العرض</label>
                                    <div class="col-md-9">
                                        <input type="text" name="order" class="form-control" placeholder="ترتيب العرض" value="<?php echo e(old('order')); ?>">
                                        <?php if($errors->has('order')): ?>
                                            <span class="help-block">
                                                   <strong style="color: red;"><?php echo e($errors->first('order')); ?></strong>
                                                </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-actions">
                            <div class="row">
                                <div class="col-md-offset-3 col-md-9">
                                    <button type="submit" class="btn green" value="حفظ" onclick="this.disabled=true;this.value='تم الارسال, انتظر...';this.form.submit();">حفظ</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!-- END SAMPLE FORM PORTLET-->

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('admin/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/components-select2.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/bootstrap-fileinput.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\orderMosb2a\resources\views/admin/pages/create_link.blade.php ENDPATH**/ ?>