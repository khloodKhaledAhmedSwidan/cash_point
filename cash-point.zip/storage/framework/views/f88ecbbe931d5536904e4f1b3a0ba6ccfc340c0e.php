<?php $__env->startSection('title'); ?>
    اعدادات الموقع
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/bootstrap-fileinput.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="/admin/home">لوحة التحكم</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="/admin/setting">اعدادات الموقع</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>تعديل اعدادات الموقع</span>
            </li>
        </ul>
    </div>

    <h1 class="page-title"> اعدادات الموقع
        <small>تعديل اعدادات الموقع</small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="row">

        <div class="col-md-8">
            <!-- BEGIN TAB PORTLET-->
            <form action="/admin/add/settings" method="post">
                <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                <div class="portlet light bordered">

                    <div class="portlet-body">

                        <div class="tabbable tabbable-tabdrop">
                            <ul class="nav nav-tabs">
                                <li class="active">
                                    <a href="#tab1" data-toggle="tab">عام</a>
                                </li>
                                <li>
                                    <a href="#tab2" data-toggle="tab">بيانات</a>
                                </li>

                            </ul>

                            <div class="tab-content">
                                <div class="tab-pane active" id="tab1">
                                    <div class="portlet light bordered">
                                        <div class="portlet-body">

                                            <div class="tabbable tabbable-tabdrop">
                                                <ul class="nav nav-tabs">
                                                    <li class="active">
                                                        <a href="#tab3" data-toggle="tab">عربي</a>
                                                    </li>
                                                    <li>
                                                        <a href="#tab4" data-toggle="tab">انجيلزي</a>
                                                    </li>

                                                </ul>

                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="tab3">
                                                        <!-- BEGIN CONTENT -->
                                                        <div class="page-content-wrapper">
                                                            <!-- BEGIN CONTENT BODY -->
                                                            <div class="row">
                                                                <!-- BEGIN SAMPLE FORM PORTLET-->
                                                                <div class="portlet light bordered">
                                                                    <div class="portlet-body form">
                                                                        <div class="form-horizontal" role="form">
                                                                            <div class="form-body">
                                                                                <div class="form-group">
                                                                                    <label class="col-md-3 control-label">اسم الموقع</label>
                                                                                    <div class="col-md-9">
                                                                                        <input type="text" class="form-control" placeholder="اسم الموقع" name="name[ar]" value="<?php echo e(unserialize($settings->name)['ar']); ?>">
                                                                                        <?php if($errors->has('name.ar')): ?>
                                                                                            <span class="help-block">
                                                                                               <strong style="color: red;"><?php echo e($errors->first('name.ar')); ?></strong>
                                                                                            </span>
                                                                                        <?php endif; ?>

                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                            <div class="form-body">
                                                                                <div class="form-group">
                                                                                    <label class="col-md-3 control-label">الوصف</label>
                                                                                    <div class="col-md-9">
                                                                                        <input type="text" class="form-control" placeholder="الوصف" name="desc[ar]" value="<?php echo e(unserialize($settings->desc)['ar']); ?>">
                                                                                        <?php if($errors->has('desc.ar')): ?>
                                                                                            <span class="help-block">
                                                                                               <strong style="color: red;"><?php echo e($errors->first('desc.ar')); ?></strong>
                                                                                            </span>
                                                                                        <?php endif; ?>

                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                            <div class="form-body">
                                                                                <div class="form-group">
                                                                                    <label class="col-md-3 control-label">كلمات دلالية</label>
                                                                                    <div class="col-md-9">
                                                                                        <input type="text" class="form-control" placeholder="كلمات دلالية" name="keywords[ar]" value="<?php echo e(unserialize($settings->keywords)['ar']); ?>">
                                                                                        <?php if($errors->has('keywords.ar')): ?>
                                                                                            <span class="help-block">
                                                                                               <strong style="color: red;"><?php echo e($errors->first('keywords.ar')); ?></strong>
                                                                                            </span>
                                                                                        <?php endif; ?>

                                                                                    </div>
                                                                                </div>

                                                                            </div>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <!-- END SAMPLE FORM PORTLET-->


                                                            </div>


                                                            <!-- END CONTENT BODY -->
                                                        </div>
                                                        <!-- END CONTENT -->
                                                    </div>
                                                    <div class="tab-pane" id="tab4">
                                                        <!-- BEGIN CONTENT -->
                                                        <div class="page-content-wrapper">
                                                            <!-- BEGIN CONTENT BODY -->

                                                            <div class="row">
                                                                <!-- BEGIN SAMPLE FORM PORTLET-->
                                                                <div class="portlet light bordered">
                                                                    <div class="portlet-body form">
                                                                        <div class="form-horizontal" role="form">
                                                                            <div class="form-body">
                                                                                <div class="form-group">
                                                                                    <label class="col-md-3 control-label">اسم الموقع</label>
                                                                                    <div class="col-md-9">
                                                                                        <input type="text" class="form-control" placeholder="اسم الموقع" name="name[en]" value="<?php echo e(unserialize($settings->name)['en']); ?>">
                                                                                        <?php if($errors->has('name.en')): ?>
                                                                                            <span class="help-block">
                                                                                               <strong style="color: red;"><?php echo e($errors->first('name.en')); ?></strong>
                                                                                            </span>
                                                                                        <?php endif; ?>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                            <div class="form-body">
                                                                                <div class="form-group">
                                                                                    <label class="col-md-3 control-label">الوصف</label>
                                                                                    <div class="col-md-9">
                                                                                        <input type="text" class="form-control" placeholder="الوصف" name="desc[en]" value="<?php echo e(unserialize($settings->desc)['en']); ?>">
                                                                                        <?php if($errors->has('desc.en')): ?>
                                                                                            <span class="help-block">
                                                                                               <strong style="color: red;"><?php echo e($errors->first('desc.en')); ?></strong>
                                                                                            </span>
                                                                                        <?php endif; ?>

                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                            <div class="form-body">
                                                                                <div class="form-group">
                                                                                    <label class="col-md-3 control-label">كلمات دلالية</label>
                                                                                    <div class="col-md-9">
                                                                                        <input type="text" class="form-control" placeholder="كلمات دلالية" name="keywords[en]" value="<?php echo e(unserialize($settings->keywords)['en']); ?>">
                                                                                        <?php if($errors->has('keywords.en')): ?>
                                                                                            <span class="help-block">
                                                                                               <strong style="color: red;"><?php echo e($errors->first('keywords.en')); ?></strong>
                                                                                            </span>
                                                                                        <?php endif; ?>

                                                                                    </div>
                                                                                </div>

                                                                            </div>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <!-- END SAMPLE FORM PORTLET-->


                                                            </div>


                                                            <!-- END CONTENT BODY -->
                                                        </div>
                                                        <!-- END CONTENT -->
                                                    </div>

                                                </div>


                                            </div>


                                            <p> &nbsp; </p>
                                            <p> &nbsp; </p>

                                        </div>
                                    </div>

                                </div>
                                <div class="tab-pane" id="tab2">
                                    <!-- BEGIN CONTENT -->
                                    <div class="page-content-wrapper">
                                        <!-- BEGIN CONTENT BODY -->

                                        <div class="row">
                                            <!-- BEGIN SAMPLE FORM PORTLET-->
                                            <div class="portlet light bordered">
                                                <div class="portlet-body form">
                                                    <div class="form-horizontal" role="form">
                                                        <div class="form-body">
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">البريد الالكتروني</label>
                                                                <div class="col-md-9">
                                                                    <div class="input-group">
                                                                            <span class="input-group-addon">
                                                                                <i class="fa fa-envelope"></i>
                                                                            </span>
                                                                        <input type="email" class="form-control" placeholder="البريد الاكتروني" name="email" value="<?php echo e($settings->email); ?>">
                                                                    </div>
                                                                    <?php if($errors->has('email')): ?>
                                                                        <span class="help-block">
                                                                               <strong style="color: red;"><?php echo e($errors->first('email')); ?></strong>
                                                                            </span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">رقم الهاتف</label>
                                                                <div class="col-md-9">
                                                                    <input type="text" class="form-control" placeholder="رقم الهاتف" name="phone_number" value="<?php echo e($settings->phone_number); ?>">
                                                                    <?php if($errors->has('phone_number')): ?>
                                                                        <span class="help-block">
                                                                           <strong style="color: red;"><?php echo e($errors->first('phone_number')); ?></strong>
                                                                        </span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>



                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <!-- END SAMPLE FORM PORTLET-->


                                        </div>


                                        <!-- END CONTENT BODY -->
                                    </div>
                                    <!-- END CONTENT -->
                                </div>

                            </div>


                        </div>


                        <p> &nbsp; </p>
                        <p> &nbsp; </p>

                    </div>
                </div>
                <div class="form-actions">
                    <div class="row">
                        <div class="col-md-offset-3 col-md-9">
                            <button type="submit" class="btn green">حفظ</button>
                        </div>
                    </div>
                </div>
            </form>
            <!-- END TAB PORTLET-->





        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('admin/js/bootstrap-fileinput.js')); ?>"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\orderMosb2a\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>