<?php $__env->startSection('title'); ?>
العمولة
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/datatables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/datatables.bootstrap-rtl.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/sweetalert.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/sweetalert.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            <a href="/admin/home">لوحة التحكم</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <a href="/admin/order/offer">العمولة</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <span>عرض العمولة</span>
        </li>
    </ul>
</div>

<h1 class="page-title">عرض العمولة
    <small>عرض جميع العمولة</small>
</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('msg')): ?>
<div class="alert alert-success">
    <?php echo e(session('msg')); ?>

</div>
<?php endif; ?>


<div class="row">
    <div class="col-md-12">
        <!-- BEGIN EXAMPLE TABLE PORTLET-->
        <div class="portlet light bordered table-responsive">

            <div class="portlet-body">

                <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                    <thead>
                    <tr>
                        <th>
                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                <input type="checkbox" class="group-checkable" data-set="#sample_1 .checkboxes" />
                                <span></span>
                            </label>
                        </th>

                        <th></th>
                        <th> اسم السواق </th>
                        <th> سعر السواق </th>
                        <th> حالة العمولة </th>
                        <th> صورة العمولة </th>
                        <th> تاريخ انتهاء دفع العمولة </th>
                        <th> خيارات </th>



                    </tr>
                    </thead>
                    <tbody>

                    <?php $i=0 ?>
                    <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr class="odd gradeX">
                            <td>
                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                    <input type="checkbox" class="checkboxes" value="1" />
                                    <span></span>
                                </label>
                            </td>
                            <td><?php echo ++$i ?></td>
                            <td> <?php echo e(\App\User::find($offer->sawaq_user_id) == null ? null : \App\User::find($offer->sawaq_user_id)->name); ?> </td>
                            <td><?php echo e($offer->price); ?></td>


                            <td>
                                <?php if($offer->commission_status !==1): ?>
                                   لم يتم الدفع بعد
                                <?php else: ?>

                                   تم دفع العمولة
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($offer->commission !== null): ?>
                                    <img   src='<?php echo e(asset("uploads/users/$offer->commission")); ?>' style="height: 50px; width: 50px;" alt="<?php echo e($offer->commission); ?>">
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($offer->end_date); ?></td>
                            <td>
                                <a href="/admin/edit/commission/<?php echo e($offer->id); ?>" class="btn btn-sm blue">
                                    <i class="icon-docs"></i> تغيير حالة العمولة</a>
                            </td>









                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div>
        </div>
        <!-- END EXAMPLE TABLE PORTLET-->
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nour\Desktop\Salamat\salam\salamat\resources\views/admin/orders/commission.blade.php ENDPATH**/ ?>