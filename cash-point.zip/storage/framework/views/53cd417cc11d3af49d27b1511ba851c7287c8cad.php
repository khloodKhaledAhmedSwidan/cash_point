<?php $__env->startSection('title'); ?>
    نسيت كلمة المرور؟
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- BEGIN FORGOT PASSWORD FORM -->
    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('admin.password.email')); ?>">
        <?php echo csrf_field(); ?>

        <h3 class="font-green">نسيت كلمة المرور؟</h3>
        <p>ادخل بريدك الالكتروني لاستعاده كلمة المرور الخاصة بك </p>
        <div class="form-group<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>">
            <input class="form-control placeholder-no-fix" type="text" autocomplete="off" placeholder="البريد الالكتروني" name="email" value="<?php echo e(old('email')); ?>" required autofocus />
            <?php if($errors->has('email')): ?>
                <div class="alert alert-danger">
                    <button class="close" data-close="alert"></button>
                    <span> <?php echo e($errors->first('email')); ?></span>
                </div>
            <?php endif; ?>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-success uppercase pull-right">ارسال</button>
        </div>
    </form>
    <!-- END FORGOT PASSWORD FORM -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.authAdmin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nour\Desktop\Salamat\salam\salamat\resources\views/admin/authAdmin/passwords/email.blade.php ENDPATH**/ ?>