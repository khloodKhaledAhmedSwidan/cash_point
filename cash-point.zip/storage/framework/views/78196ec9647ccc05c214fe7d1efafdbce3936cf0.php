<?php $__env->startSection('title'); ?>
    اضافة اعدادات وسائل التواصل الاجتماعي
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/select2-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/bootstrap-fileinput.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_header'); ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="/admin/home">لوحة التحكم</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="/admin/setting/socialMedia">اعدادات وسائل التواصل الاجتماعي</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>اضافة اعدادات وسائل التواصل الاجتماعي</span>
            </li>
        </ul>
    </div>

    <h1 class="page-title"> اعدادات وسائل التواصل الاجتماعي
        <small>اضافة اعدادات وسائل التواصل الاجتماعي</small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-md-8">
            <!-- BEGIN TAB PORTLET-->
            <form method="post" action="/admin/add/Social" enctype="multipart/form-data">
                <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                <div class="portlet light bordered">

                    <div class="portlet-body">

                        <div class="tabbable tabbable-tabdrop">
                            <ul class="nav nav-tabs">
                                <li class="active">
                                    <a href="#tab1" data-toggle="tab">عام</a>
                                </li>
                                <li>
                                    <a href="#tab2" data-toggle="tab">بيانات</a>
                                </li>

                            </ul>

                            <div class="tab-content">
                                <div class="tab-pane active" id="tab1">
                                    <div class="portlet light bordered">
                                        <div class="portlet-body">

                                            <div class="tabbable tabbable-tabdrop">
                                                <ul class="nav nav-tabs">
                                                    <li class="active">
                                                        <a href="#tab3" data-toggle="tab">عربي</a>
                                                    </li>
                                                    <li>
                                                        <a href="#tab4" data-toggle="tab">انجيلزي</a>
                                                    </li>

                                                </ul>

                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="tab3">
                                                        <!-- BEGIN CONTENT -->
                                                        <div class="page-content-wrapper">
                                                            <!-- BEGIN CONTENT BODY -->
                                                            <div class="row">
                                                                <!-- BEGIN SAMPLE FORM PORTLET-->
                                                                <div class="portlet light bordered">
                                                                    <div class="portlet-body form">
                                                                        <div class="form-horizontal" role="form">
                                                                            <div class="form-group">
                                                                                <label class="col-md-3 control-label">الاسم</label>
                                                                                <div class="col-md-9">
                                                                                    <input type="text" name="name_social[ar]" class="form-control" placeholder="الاسم" value="<?php echo e(old('name_social.ar')); ?>">
                                                                                    <?php if($errors->has('name_social.ar')): ?>
                                                                                        <span class="help-block">
                                                                                           <strong style="color: red;"><?php echo e($errors->first('name_social.ar')); ?></strong>
                                                                                        </span>
                                                                                    <?php endif; ?>
                                                                                </div>
                                                                            </div>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <!-- END SAMPLE FORM PORTLET-->


                                                            </div>


                                                            <!-- END CONTENT BODY -->
                                                        </div>
                                                        <!-- END CONTENT -->
                                                    </div>
                                                    <div class="tab-pane" id="tab4">
                                                        <!-- BEGIN CONTENT -->
                                                        <div class="page-content-wrapper">
                                                            <!-- BEGIN CONTENT BODY -->

                                                            <div class="row">
                                                                <!-- BEGIN SAMPLE FORM PORTLET-->
                                                                <div class="portlet light bordered">
                                                                    <div class="portlet-body form">
                                                                        <div class="form-horizontal" role="form">
                                                                            <div class="form-body">
                                                                                <div class="form-group">
                                                                                    <label class="col-md-3 control-label">الاسم</label>
                                                                                    <div class="col-md-9">
                                                                                        <input type="text" name="name_social[en]" class="form-control" placeholder="الاسم" value="<?php echo e(old('name_social.en')); ?>">
                                                                                        <?php if($errors->has('name_social.en')): ?>
                                                                                            <span class="help-block">
                                                                                               <strong style="color: red;"><?php echo e($errors->first('name_social.en')); ?></strong>
                                                                                            </span>
                                                                                        <?php endif; ?>
                                                                                    </div>
                                                                                </div>



                                                                            </div>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <!-- END SAMPLE FORM PORTLET-->


                                                            </div>


                                                            <!-- END CONTENT BODY -->
                                                        </div>
                                                        <!-- END CONTENT -->
                                                    </div>

                                                </div>


                                            </div>


                                            <p> &nbsp; </p>
                                            <p> &nbsp; </p>

                                        </div>
                                    </div>

                                </div>
                                <div class="tab-pane" id="tab2">
                                    <!-- BEGIN CONTENT -->
                                    <div class="page-content-wrapper">
                                        <!-- BEGIN CONTENT BODY -->

                                        <div class="row">
                                            <!-- BEGIN SAMPLE FORM PORTLET-->
                                            <div class="portlet light bordered">
                                                <div class="portlet-body form">
                                                    <div class="form-horizontal" role="form">
                                                        <div class="form-body">

                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">ايقونة</label>
                                                                <div class="col-md-9">
                                                                    <input type="text" name="icon" class="form-control my_icon" placeholder="ايقونة" value="<?php echo e(old('icon')); ?>">
                                                                    <?php if($errors->has('icon')): ?>
                                                                        <span class="help-block">
                                                                           <strong style="color: red;"><?php echo e($errors->first('icon')); ?></strong>
                                                                        </span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">الرابط</label>
                                                                <div class="col-md-9">
                                                                    <input type="text" name="link" class="form-control" placeholder="الرابط" value="<?php echo e(old('link')); ?>">
                                                                    <?php if($errors->has('link')): ?>
                                                                        <span class="help-block">
                                                                           <strong style="color: red;"><?php echo e($errors->first('link')); ?></strong>
                                                                        </span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>


                                                            <div class="form-group">
                                                                <label for="gender" class="col-md-3 control-label">اختر النوع</label>
                                                                <div class="col-lg-9">
                                                                    <div class=" input-group select2-bootstrap-append">
                                                                        <select id="gender" name="type" class="form-control select2-allow-clear">
                                                                            <option value="link"  <?php echo e(old('type') == "link" ? 'selected' : ''); ?>>رابط</option>
                                                                            <option value="phone" <?php echo e(old('type') == "phone" ? 'selected' : ''); ?>>رقم</option>
                                                                            <option value="email" <?php echo e(old('type') == "email" ? 'selected' : ''); ?>>بريد الكتروني</option>

                                                                        </select>
                                                                        <?php if($errors->has('type')): ?>
                                                                            <span class="help-block">
                                                                               <strong style="color: red;"><?php echo e($errors->first('type')); ?></strong>
                                                                            </span>
                                                                        <?php endif; ?>
                                                                        <span class="input-group-btn">
                                                        <button class="btn btn-default" type="button" data-select2-open="single-append-text">
                                                            <span class="glyphicon glyphicon-search"></span>
                                                        </button>
                                                    </span>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <!-- END SAMPLE FORM PORTLET-->


                                        </div>


                                        <!-- END CONTENT BODY -->
                                    </div>
                                    <!-- END CONTENT -->
                                </div>

                            </div>


                        </div>


                        <p> &nbsp; </p>
                        <p> &nbsp; </p>

                    </div>
                </div>
                <div class="form-actions">
                    <div class="row">
                        <div class="col-md-offset-3 col-md-9">
                            <button type="submit" class="btn green" value="حفظ" onclick="this.disabled=true;this.value='تم الارسال, انتظر...';this.form.submit();">حفظ</button>
                        </div>
                    </div>
                </div>
            </form>
            <!-- END TAB PORTLET-->





        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('admin/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/components-select2.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/bootstrap-fileinput.js')); ?>"></script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\orderMosb2a\resources\views/admin/socialSettings/create.blade.php ENDPATH**/ ?>