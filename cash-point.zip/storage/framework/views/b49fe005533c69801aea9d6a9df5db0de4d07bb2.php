<?php echo e($slot); ?>

<?php /**PATH C:\Users\elsawah\Desktop\tqnee\keshof\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>