<?php $__env->startSection('title'); ?>
    مجموعات المشرفين
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/blog-rtl.min.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="<?php echo e(url('admin/home')); ?>">لوحة التحكم</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="<?php echo e(url('/admin/roles')); ?>">مجموعات المشرفين</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>مجموعات المشرفين</span>
            </li>
        </ul>
    </div>

    <h1 class="page-title"> عرض مجموعة
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="blog-page blog-content-2">
        <div class="row">
            <div class="col-lg-9">
                <div class="blog-single-content bordered blog-container">
                    <div class="blog-single-head">
                        <h1 class="blog-single-head-title" style="max-width: 75%;">
                            <?php echo e($item->role_name); ?>

                        </h1>
                        <div class="blog-single-head-date">
                            <i class="icon-calendar font-blue"></i>
                            <a><?php echo e($item->created_at); ?></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                    <div class="blog-single-sidebar bordered blog-container" style="padding: 10px 30px 15px">
                    <div class="blog-single-sidebar-links">
                        <h3 class="blog-sidebar-title uppercase">عدد الإعضاء</h3>
                        <ul>
                            <li>
                                <span class="label label-sm label-danger">
                                    <?php if($members): ?>
                                        <?php echo e($members); ?> عضو
                                    <?php else: ?>
                                        لا يوجد
                                    <?php endif; ?>
                                </span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div style="clear: both"></div>
            <div class="col-md-12">
                <h1 class="page-title" style="margin-top: 0"> الصلاحيات
                </h1>
                <form class="form-horizontal" method="post" action="<?php echo e(url('/admin/update_permission/' . $item->id)); ?>">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="_method" value="PATCH">

                    <div class="portlet light bordered">
                        <?php
                        $admins = [];
                        $contacts = [];
                       $roles = [];$settings = [];$social_settings = [];
                        $important_links = [];
                        $pages =[];
                        ?>
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($value->table_name === 'admins'): ?>
                                    <?php array_push($admins, ['permission_name' => $value->permission_name, 'id' => $value->id]) ?>
                                <?php endif; ?>




                                <?php if($value->table_name === 'roles'): ?>
                                    <?php array_push($roles, ['permission_name' => $value->permission_name, 'id' => $value->id]) ?>
                                <?php endif; ?>
                                <?php if($value->table_name === 'settings'): ?>
                                    <?php array_push($settings, ['permission_name' => $value->permission_name, 'id' => $value->id]) ?>
                                <?php endif; ?>
                                <?php if($value->table_name === 'social_settings'): ?>
                                    <?php array_push($social_settings, ['permission_name' => $value->permission_name, 'id' => $value->id]) ?>
                                <?php endif; ?>
                                <?php if($value->table_name === 'pages'): ?>
                                    <?php array_push($pages, ['permission_name' => $value->permission_name, 'id' => $value->id]) ?>
                                <?php endif; ?>
                                <?php if($value->table_name === 'important_links'): ?>
                                    <?php array_push($important_links, ['permission_name' => $value->permission_name, 'id' => $value->id]) ?>
                                <?php endif; ?>

                                <?php if($value->table_name === 'contacts'): ?>
                                    <?php array_push($contacts, ['permission_name' => $value->permission_name, 'id' => $value->id]) ?>
                                <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="form-group form-md-checkboxes  col-md-12">
                                <label class="col-md-12"><?php echo app('translator')->getFromJson('permissions.admins'); ?></label>
                                <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="md-checkbox col-md-3">
                                        <?php $true = 0 ;?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($value->permission_id == $role['id']): ?>
                                                <?php $true++;?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <input type="checkbox" id="<?php echo e($role['id']); ?>" name="permission[]" class="md-check" value="<?php echo e($role['id']); ?>" <?php if(!$true): ?>  <?php else: ?> checked  <?php endif; ?>>
                                        <label for="<?php echo e($role['id']); ?>">
                                            <span></span>
                                            <span class="check"></span>
                                            <span class="box"></span> <?php echo app('translator')->getFromJson('permissions.' . $role['permission_name']); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>



                            <hr class="col-md-11">
                            <div class="form-group form-md-checkboxes  col-md-12">
                                <label class="col-md-12"><?php echo app('translator')->getFromJson('permissions.settings'); ?></label>
                                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="md-checkbox col-md-3">
                                        <?php $true = 0 ;?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($value->permission_id == $role['id']): ?>
                                                <?php $true++;?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <input type="checkbox" id="<?php echo e($role['id']); ?>" name="permission[]" class="md-check" value="<?php echo e($role['id']); ?>" <?php if(!$true): ?>  <?php else: ?> checked  <?php endif; ?>>
                                        <label for="<?php echo e($role['id']); ?>">
                                            <span></span>
                                            <span class="check"></span>
                                            <span class="box"></span> <?php echo app('translator')->getFromJson('permissions.' . $role['permission_name']); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <hr class="col-md-11">
                            <div class="form-group form-md-checkboxes  col-md-12">
                                <label class="col-md-12"><?php echo app('translator')->getFromJson('permissions.social_settings'); ?></label>
                                <?php $__currentLoopData = $social_settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="md-checkbox col-md-3">
                                        <?php $true = 0 ;?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($value->permission_id == $role['id']): ?>
                                                <?php $true++;?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <input type="checkbox" id="<?php echo e($role['id']); ?>" name="permission[]" class="md-check" value="<?php echo e($role['id']); ?>" <?php if(!$true): ?>  <?php else: ?> checked  <?php endif; ?>>
                                        <label for="<?php echo e($role['id']); ?>">
                                            <span></span>
                                            <span class="check"></span>
                                            <span class="box"></span> <?php echo app('translator')->getFromJson('permissions.' . $role['permission_name']); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <hr class="col-md-11">
                            <div class="form-group form-md-checkboxes  col-md-12">
                                <label class="col-md-12"><?php echo app('translator')->getFromJson('permissions.pages'); ?></label>
                                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="md-checkbox col-md-3">
                                        <?php $true = 0 ;?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($value->permission_id == $role['id']): ?>
                                                <?php $true++;?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <input type="checkbox" id="<?php echo e($role['id']); ?>" name="permission[]" class="md-check" value="<?php echo e($role['id']); ?>" <?php if(!$true): ?>  <?php else: ?> checked  <?php endif; ?>>
                                        <label for="<?php echo e($role['id']); ?>">
                                            <span></span>
                                            <span class="check"></span>
                                            <span class="box"></span> <?php echo app('translator')->getFromJson('permissions.' . $role['permission_name']); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <hr class="col-md-11">
                            <div class="form-group form-md-checkboxes  col-md-12">
                                <label class="col-md-12"><?php echo app('translator')->getFromJson('permissions.important_links'); ?></label>
                                <?php $__currentLoopData = $important_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="md-checkbox col-md-3">
                                        <?php $true = 0 ;?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($value->permission_id == $role['id']): ?>
                                                <?php $true++;?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <input type="checkbox" id="<?php echo e($role['id']); ?>" name="permission[]" class="md-check" value="<?php echo e($role['id']); ?>" <?php if(!$true): ?>  <?php else: ?> checked  <?php endif; ?>>
                                        <label for="<?php echo e($role['id']); ?>">
                                            <span></span>
                                            <span class="check"></span>
                                            <span class="box"></span> <?php echo app('translator')->getFromJson('permissions.' . $role['permission_name']); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>



                            <hr class="col-md-11">
                            <div class="form-group form-md-checkboxes  col-md-12">
                                <label class="col-md-12"><?php echo app('translator')->getFromJson('permissions.contacts'); ?></label>
                                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="md-checkbox col-md-3">
                                        <?php $true = 0 ;?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($value->permission_id == $role['id']): ?>
                                                <?php $true++;?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <input type="checkbox" id="<?php echo e($role['id']); ?>" name="permission[]" class="md-check" value="<?php echo e($role['id']); ?>" <?php if(!$true): ?>  <?php else: ?> checked  <?php endif; ?>>
                                        <label for="<?php echo e($role['id']); ?>">
                                            <span></span>
                                            <span class="check"></span>
                                            <span class="box"></span> <?php echo app('translator')->getFromJson('permissions.' . $role['permission_name']); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>






                            <hr class="col-md-11">
                            <div class="form-group form-md-checkboxes  col-md-12">
                                <label class="col-md-12"><?php echo app('translator')->getFromJson('permissions.roles'); ?></label>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="md-checkbox col-md-3">
                                        <?php $true = 0 ;?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($value->permission_id == $role['id']): ?>
                                                <?php $true++;?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <input type="checkbox" id="<?php echo e($role['id']); ?>" name="permission[]" class="md-check" value="<?php echo e($role['id']); ?>" <?php if(!$true): ?>  <?php else: ?> checked  <?php endif; ?>>
                                        <label for="<?php echo e($role['id']); ?>">
                                            <span></span>
                                            <span class="check"></span>
                                            <span class="box"></span> <?php echo app('translator')->getFromJson('permissions.' . $role['permission_name']); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <hr class="col-md-11">

                        <div class="form-actions">
                            <div class="row">
                                <div class="col-lg-2 col-lg-offset-10">
                                    
                                    <input class="btn green btn-block" type="submit" value="حفظ" onclick="this.disabled=true;this.value='تم الارسال, انتظر...';this.form.submit();" />
                                </div>
                            </div>
                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\orderMosb2a\resources\views/admin/admins/groups/show.blade.php ENDPATH**/ ?>