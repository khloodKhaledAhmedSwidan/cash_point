<?php $__env->startSection('title'); ?>
    الروابط
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/datatables.bootstrap-rtl.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/sweetalert.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/sweetalert.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="/admin/home">لوحة التحكم</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="/admin/setting/pageLinks">الروابط</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>عرض الروابط</span>
            </li>
        </ul>
    </div>

    <h1 class="page-title">عرض الروابط
        <small> بيانات الروابط</small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-md-12">
            <!-- BEGIN EXAMPLE TABLE PORTLET-->
            <div class="portlet light bordered">

                <div class="portlet-body">
                    <div class="table-toolbar">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="btn-group">
                                    <a href="/admin/add/link">
                                        <button id="sample_editable_1_new" class="btn sbold green"> اضافة جديد
                                            <i class="fa fa-plus"></i>
                                        </button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                        <thead>
                        <tr>
                            <th>
                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                    <input type="checkbox" class="group-checkable" data-set="#sample_1 .checkboxes" />
                                    <span></span>
                                </label>
                            </th>
                            <th></th>
                            <th> اسم الصفحة باللغة العربية</th>
                            <th> اسم الصفحة باللغة الانجيلزية </th>
                            <th>المكان </th>
                            <th>ترتيب العرض </th>




                            <th> خيارات </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $i=0 ?>
                        <?php $__currentLoopData = $important_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="odd gradeX">
                                <td>
                                    <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                        <input type="checkbox" class="checkboxes" value="1" />
                                        <span></span>
                                    </label>
                                </td>
                                <td><?php echo ++$i ?></td>
                                <td> <?php echo e(unserialize($link->name)['ar']); ?> </td>
                                <td> <?php echo e(unserialize($link->name)['en']); ?> </td>


                                <td><?php echo e($link->place); ?> </td>
                                <td><?php echo e($link->order); ?> </td>




                                <td>

                                    <div class="btn-group">
                                        <button class="btn btn-xs green dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"> خيارات
                                            <i class="fa fa-angle-down"></i>
                                        </button>
                                        <ul class="dropdown-menu pull-left" role="menu">

                                            <li>
                                                <a href="/admin/edit/link/<?php echo e($link->id); ?>">
                                                    <i class="icon-docs"></i> تعديل </a>
                                            </li>

                                            <li>
                                                <a class="delete_user" data="<?php echo e($link->id); ?>" data_name="<?php echo e(unserialize($link->name)['ar']); ?>" >
                                                    <i class="fa fa-key"></i> مسح
                                                </a>
                                            </li>


                                        </ul>
                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- END EXAMPLE TABLE PORTLET-->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('admin/js/datatable.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/datatables.bootstrap.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/table-datatables-managed.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/sweetalert.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/ui-sweetalert.min.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            var CSRF_TOKEN = $('meta[name="X-CSRF-TOKEN"]').attr('content');

            $('body').on('click', '.delete_user', function() {
                var id = $(this).attr('data');

                var swal_text = 'حذف ' + $(this).attr('data_name') + '؟';
                var swal_title = 'هل أنت متأكد من الحذف ؟';

                swal({
                    title: swal_title,
                    text: swal_text,
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonClass: "btn-warning",
                    confirmButtonText: "تأكيد",
                    cancelButtonText: "إغلاق",
                    closeOnConfirm: false
                }, function() {

                    window.location.href = "<?php echo e(url('/')); ?>" + "/admin/delete/"+id+"/link";


                });

            });

        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\orderMosb2a\resources\views/admin/pages/links_page.blade.php ENDPATH**/ ?>