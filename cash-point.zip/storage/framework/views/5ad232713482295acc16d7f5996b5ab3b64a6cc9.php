<?php $__env->startSection('title'); ?>
    المشرفين
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/select2-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/bootstrap-fileinput.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/datatables.bootstrap-rtl.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/sweetalert.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="<?php echo e(url('admin/home')); ?>">لوحة التحكم</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="<?php echo e(route('admins.index')); ?>">المشرفين</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>عرض تغيير كلمة المرور</span>
            </li>
        </ul>
    </div>

    <h1 class="page-title">عرض تغيير كلمة المرور
        <small>تعديل تغيير كلمة المرور</small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session()->has('msg')): ?>

        <p class="alert alert-success" style="width: 100%">

            <?php echo e(session()->get('msg')); ?>


        </p>
    <?php endif; ?>

    <form class="form-horizontal" method="post" action="<?php echo e(url('/admin/profileChangePass')); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>


        <div class="row">
            <div class="col-lg-8">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption font-red-sunglo">
                            <i class="icon-settings font-red-sunglo"></i>
                            <span class="caption-subject bold uppercase"> البيانات الرئيسية</span>
                        </div>
                    </div>
                    <div class="portlet-body form">
                        <div class="btn-group"></div>


                        <div class="form-group">
                            <label for="password" class="col-lg-3 control-label">الرقم السرى</label>
                            <div class="col-lg-9">
                                <input id="password" name="password" type="password" class="form-control" required>
                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                       <strong style="color: red;"><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password_confirm" class="col-lg-3 control-label">اعد كتابة الرقم السرى</label>
                            <div class="col-lg-9">
                                <input id="password_confirm" name="password_confirmation" type="password" class="form-control" required>
                                <?php if($errors->has('password_confirmation')): ?>
                                    <span class="help-block">
                                       <strong style="color: red;"><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>




                        <div style="clear: both"></div>

                        <div class="form-actions">
                            <div class="row">
                                <div class="col-lg-2 col-lg-offset-10">
                                    
                                    <input class="btn green btn-block" type="submit" value="حفظ" onclick="this.disabled=true;this.value='تم الارسال, انتظر...';this.form.submit();" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </form>

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('admin/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/components-select2.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/bootstrap-fileinput.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sawaq\resources\views/admin/admins/profile/change_pass.blade.php ENDPATH**/ ?>