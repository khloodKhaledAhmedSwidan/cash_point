<?php $__env->startSection('title'); ?>
    اضافة مستخدم
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/select2-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/bootstrap-fileinput.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="/admin/home">لوحة التحكم</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="<?php echo e(url('/admin/users')); ?>">المستخدمين</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>اضافة مستخدم</span>
            </li>
        </ul>
    </div>

    <h1 class="page-title"> المستخدمين
        <small>اضافة مستخدم</small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



    <!-- END PAGE TITLE-->
    <!-- END PAGE HEADER-->
    <div class="row">
        <div class="col-md-12">

            <!-- BEGIN PROFILE CONTENT -->
            <div class="profile-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="portlet light ">
                            <div class="portlet-title tabbable-line">
                                <div class="caption caption-md">
                                    <i class="icon-globe theme-font hide"></i>
                                    <span class="caption-subject font-blue-madison bold uppercase">حساب الملف الشخصي</span>
                                </div>
                                <ul class="nav nav-tabs">
                                    <li class="active">
                                        <a href="#tab_1_1" data-toggle="tab">المعلومات الشخصية</a>
                                    </li>

                                    <li>
                                        <a href="#tab_1_4" data-toggle="tab">اعدادات الخصوصية</a>
                                    </li>
                                </ul>
                            </div>
                            <form role="form" action="/admin/add/user" method="post" enctype="multipart/form-data">
                                <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                                <div class="portlet-body">

                                    <div class="tab-content">
                                        <!-- PERSONAL INFO TAB -->
                                        <div class="tab-pane active" id="tab_1_1">


                                            <div class="form-group">
                                                <label class="control-label">الاسم</label>
                                                <input type="text" name="name" placeholder="الاسم" class="form-control" value="<?php echo e(old('name')); ?>" />
                                                <?php if($errors->has('name')): ?>
                                                    <span class="help-block">
                                                       <strong style="color: red;"><?php echo e($errors->first('name')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>


                                            <div class="form-group">
                                                <label class="control-label">البريد الألكتروني</label>

                                                <input type="email" name="email" placeholder="البريد الألكتروني" class="form-control" value="<?php echo e(old('email')); ?>" />
                                                <?php if($errors->has('email')): ?>
                                                    <span class="help-block">
                                                       <strong style="color: red;"><?php echo e($errors->first('email')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label">كلمة المرور</label>
                                                <input type="password" name="password" class="form-control" />
                                                <?php if($errors->has('password')): ?>
                                                    <span class="help-block">
                                                       <strong style="color: red;"><?php echo e($errors->first('password')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label">إعادة كلمة المرور</label>
                                                <input type="password" name="password_confirmation" class="form-control" />
                                                <?php if($errors->has('password_confirmation')): ?>
                                                    <span class="help-block">
                                                       <strong style="color: red;"><?php echo e($errors->first('password_confirmation')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label">أسم المدرسة</label>
                                                <input type="text" name="school_name" placeholder="أسم المدرسة" class="form-control" value="<?php echo e(old('school_name')); ?>" />
                                                <?php if($errors->has('school_name')): ?>
                                                    <span class="help-block">
                                                       <strong style="color: red;"><?php echo e($errors->first('school_name')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label"> ملاحظات </label>
                                                <input type="text" name="notes" placeholder="  ملاحظات" class="form-control" value="<?php echo e(old('notes')); ?>" />
                                                <?php if($errors->has('notes')): ?>
                                                    <span class="help-block">
                                                       <strong style="color: red;"><?php echo e($errors->first('notes')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label"> النوع </label>
                                                <input type="radio" name="gender" placeholder=""   value="0" /> أنثي
                                                <input type="radio" name="gender" placeholder=""   value="1" /> ذكر
                                                <?php if($errors->has('gender')): ?>
                                                    <span class="help-block">
                                                       <strong style="color: red;"><?php echo e($errors->first('gender')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label"> نوع الأشتراك </label>
                                                <input type="radio" name="subscription" placeholder=""   value="0" /> مجاني
                                                <input type="radio" name="subscription" placeholder=""   value="1" /> مدفوع
                                                <?php if($errors->has('subscription')): ?>
                                                    <span class="help-block">
                                                       <strong style="color: red;"><?php echo e($errors->first('subscription')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-body">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-3">الصورة الشخصية</label>
                                                    <div class="col-md-9">
                                                        <div class="fileinput fileinput-new" data-provides="fileinput">
                                                            <div class="fileinput-preview thumbnail" data-trigger="fileinput" style="width: 200px; height: 150px;">
                                                            </div>
                                                            <div>
                                                            <span class="btn red btn-outline btn-file">
                                                                <span class="fileinput-new"> اختر الصورة </span>
                                                                <span class="fileinput-exists"> تغيير </span>
                                                                <input type="file" name="image"> </span>
                                                                <a href="javascript:;" class="btn red fileinput-exists" data-dismiss="fileinput"> إزالة </a>



                                                            </div>
                                                        </div>
                                                        <?php if($errors->has('image')): ?>
                                                            <span class="help-block">
                                                               <strong style="color: red;"><?php echo e($errors->first('image')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>

                                                </div>
                                            </div>

                                        </div>
                                        <!-- END PERSONAL INFO TAB -->


                                        <!-- PRIVACY SETTINGS TAB -->
                                        <div class="tab-pane" id="tab_1_4">

                                            <table class="table table-light table-hover">

                                                <tr>
                                                    <td> تفعيل المستخدم</td>
                                                    <td>
                                                        <div class="mt-radio-inline">
                                                            <label class="mt-radio">
                                                                <input type="radio" name="active" value="1" <?php echo e(old('active') == "1" ? 'checked' : ''); ?>/> نعم
                                                                <span></span>
                                                            </label>
                                                            <label class="mt-radio">
                                                                <input type="radio" name="active" value="0" <?php echo e(old('active') == "0" ? 'checked' : ''); ?>/> لا
                                                                <span></span>
                                                            </label>
                                                            <?php if($errors->has('active')): ?>
                                                                <span class="help-block">
                                                                       <strong style="color: red;"><?php echo e($errors->first('active')); ?></strong>
                                                                    </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                </tr>


                                            </table>


                                        </div>
                                        <!-- END PRIVACY SETTINGS TAB -->
                                    </div>

                                </div>
                                <div class="margiv-top-10">
                                    <div class="form-actions">
                                        <button type="submit" class="btn green" value="حفظ" onclick="this.disabled=true;this.value='تم الارسال, انتظر...';this.form.submit();">حفظ</button>

                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END PROFILE CONTENT -->
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('admin/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/components-select2.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/bootstrap-fileinput.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('select[name="address[country]"]').on('change', function() {
                var id = $(this).val();
                $.ajax({
                    url: '/get/cities/'+id,
                    type: "GET",
                    dataType: "json",
                    success:function(data) {
                        $('#register_city').empty();



                        $('select[name="address[city]"]').append('<option value>المدينة</option>');
                        // $('select[name="city"]').append('<option value>المدينة</option>');
                        $.each(data['cities'], function(index , cities) {

                            $('select[name="address[city]"]').append('<option value="'+ cities.id +'">'+cities.name+'</option>');

                        });


                    }
                });



            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\elsawah\Desktop\tqnee\keshof\resources\views/admin/users/create.blade.php ENDPATH**/ ?>