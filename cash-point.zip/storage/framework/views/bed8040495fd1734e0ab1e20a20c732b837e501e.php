<?php $__env->startSection('title'); ?>
    تعديل الاسلايدر
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/select2-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/bootstrap-fileinput.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="/admin/home">لوحة التحكم</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="/admin/sliders">الاسلايدر</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>تعديل الاسلايدر</span>
            </li>
        </ul>
    </div>

    <h1 class="page-title"> الاسلايدر
        <small>تعديل الاسلايدر</small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <?php if(session('information')): ?>
        <div class="alert alert-success">
            <?php echo e(session('information')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('pass')): ?>
        <div class="alert alert-success">
            <?php echo e(session('pass')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('privacy')): ?>
        <div class="alert alert-success">
            <?php echo e(session('privacy')); ?>

        </div>
    <?php endif; ?>
    <?php if(count($errors)): ?>
        <ul class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
    <!-- END PAGE TITLE-->
    <!-- END PAGE HEADER-->
    <div class="row">
        <div class="col-md-12">

            <!-- BEGIN PROFILE CONTENT -->
            <div class="profile-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="portlet light ">
                
                            <div class="portlet-body">
                                <div class="tab-content">
                                    <!-- PERSONAL INFO TAB -->
                                    <div class="tab-pane active" id="tab_1_1">
                                        <form role="form" action="<?php echo e(route('sliders.update',$slider->id)); ?>" method="post" enctype="multipart/form-data">
                                            <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
<?php echo method_field('PUT'); ?>
<div class="form-group">
    <label class="control-label">اللينك </label>
    <input type="text" name="link" placeholder="اللينك " class="form-control" value="<?php echo e($slider->link); ?>" />
    <?php if($errors->has('link')): ?>
        <span class="help-block">
           <strong style="color: red;"><?php echo e($errors->first('link')); ?></strong>
        </span>
    <?php endif; ?>
</div>




    <div class="form-group">
        <label class="control-label">اختر قسم</label>
 
           <select name="category_id" class="form-control" required>
           <option selected disabled> اختر قسم  </option>
           <?php $__currentLoopData = App\Models\Category::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($category->id); ?>" <?php if($category->id == $slider->category_id): ?> selected <?php endif; ?>><?php echo e($category->name); ?> </option>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
            <?php if($errors->has('category_id')): ?>
                <span class="help-block">
                   <strong style="color: red;"><?php echo e($errors->first('category_id')); ?></strong>
                </span>
            <?php endif; ?>
       
    </div>

                                            <div class="form-body">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-3">الصورة</label>
                                                    <div class="col-md-9">
                                                        <div class="fileinput fileinput-new" data-provides="fileinput">
                                                            <div class="fileinput-preview thumbnail"
                                                                 data-trigger="fileinput"
                                                                 style="width: 200px; height: 150px;">
                                                                <img src="<?php echo e(asset('uploads/sliders/'.$slider->image)); ?>"
                                                                     alt="">
                                                            </div>
                                                            <div>
                                                            <span class="btn red btn-outline btn-file">
                                                                <span class="fileinput-new">اختر صورة </span>
                                                                <span class="fileinput-exists"><?php echo app('translator')->getFromJson('messages.change'); ?> </span>
                                                                <input type="file" name="image"> </span>
                                                                <a href="javascript:;" class="btn red fileinput-exists"
                                                                   data-dismiss="fileinput">ازالة </a>
                                                            </div>
                                                        </div>
                                                        <?php if($errors->has('image')): ?>
                                                            <span class="help-block">
                                                        <strong style="color: red;"><?php echo e($errors->first('image')); ?>

                                                        </strong>
                                                    </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
              
                                            <div class="margiv-top-10">
                                                <div class="form-actions">
                                                    <button type="submit" class="btn green">حفظ</button>

                                                </div>
                                            </div>
                                        </form>
                                    </div>
                         
                                    <!-- END PRIVACY SETTINGS TAB -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END PROFILE CONTENT -->
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('admin/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/components-select2.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/bootstrap-fileinput.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            // for get regions
            $('select[name="city_id"]').on('change', function() {
                var id = $(this).val();
                if (id) {
                    $.ajax({
                        url: '/admin/get/regions/' + id,
                        type: "GET",
                        dataType: "json",
                        success: function (data) {
                            $('#choose_region').empty();
                            $('#places').empty();
                            $('#choose_city').empty();

                            $('select[name="c"]').append('<option value>اختر المنطقة</option>');
                            $.each(data['regions'], function (index, regions) {

                                $('select[name="region_id"]').append('<option value="' + regions.id + '">' + regions.name + '</option>');

                            });
                            $('select[name="places"]').append('<option value>اختر المنطقة</option>');
                            $.each(data['regions'], function (index, regions) {

                                $('select[name="places"]').append('<option value="' + regions.id + '">' + regions.name + '</option>');

                            });


                        }
                    });
                }else{
                    $('#choose_region').empty();
                    $('#places').empty();
                    $('#choose_city').empty();
                }
            });


            $( "body" ).on( "change", "input[type=radio][name=multi_place]", function() {
                // $( this ).after( "<p>Another paragraph! " + (++count) + "</p>" );

                all_payment_status = $(this).val();
                var id = $(this).val();
                if (id == "1") {

                    $('#multi_placce').show();



                }else{
                    $('#multi_placce').hide();


                }


            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\TQNEE\cash-point\resources\views/admin/sliders/edit.blade.php ENDPATH**/ ?>