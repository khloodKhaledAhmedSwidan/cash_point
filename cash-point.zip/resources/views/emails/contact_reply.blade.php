<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>
<h2> {{ $headingTitle }} </h2>
<div>
    <p>
        <span> Your Message: </span><br>
        {{ $userMessage }}
    </p><br>
    <p>
        <span> Admin Reply: </span><br>
        {{ $contactReply }}
    </p><br>
</div>
</body>
</html>